# Agent Prompt Templates

## Overview

The AI Agent Framework now supports **configurable prompt templates** for both system and user prompts. This allows you to create highly customized agents with sophisticated prompt engineering, dynamic content injection, and context-aware responses.

## Key Features

- 🎯 **Template Variables**: Use `{{variable_name}}` placeholders for dynamic content
- 🔧 **System & User Templates**: Separate templates for system prompts and user message formatting
- 📚 **Knowledge Context**: Automatic integration with RAG (Retrieval Augmented Generation)
- ⚙️ **Custom Instructions**: Per-agent configuration overrides
- 🕒 **Dynamic Context**: Automatic date/time, agent metadata, and custom variables

## Template Syntax

The framework now supports two template syntaxes:

### 1. String Template (Recommended)
Uses Java-style `${variable}` syntax:
```yaml
template: "You are ${agent_name}, ${agent_description}. Current time: ${current_datetime}"
```

### 2. Mustache-Style (Legacy)
Uses Mustache-style `{{variable}}` syntax:
```yaml
template: "You are {{agent_name}}, {{agent_description}}. Current time: {{current_datetime}}"
```

Both syntaxes are supported in all templates, but string template syntax is recommended for better readability and consistency with Java standards.

### Available Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `{{agent_name}}` | Agent's configured name | `"research-agent"` |
| `{{agent_description}}` | Agent's description | `"Research specialist AI agent"` |
| `{{current_datetime}}` | Current date and time | `"2024-01-15 14:30:25"` |
| `{{user_message}}` | The user's input message | `"What is quantum computing?"` |
| `{{knowledge_context}}` | RAG context from knowledge base | `"Relevant context from knowledge base:\n---\n..."` |
| `{{additional_context}}` | Custom context from API calls | Custom data passed via context |
| `{{custom_instructions}}` | Agent-specific instructions | From agent configuration |

## Configuration

### YAML Configuration with String Templates

```yaml
application:
  genai:
    agents:
      configurations:
        my-custom-agent:
          name: my-custom-agent
          description: "Custom AI assistant"
          enabled: true
          model: gpt-4o-mini
          temperature: 0.2
          max-tokens: 4000
          configuration:
            provider: openai
            timeout: 30
            custom_instructions: "Always provide detailed explanations."
          prompt-templates:
            system: |
              You are ${agent_name}, ${agent_description}.
              
              Current date and time: ${current_datetime}
              
              Instructions:
              - Be helpful and accurate
              - Use the knowledge context when available
              - ${custom_instructions}
            user: |
              ${knowledge_context}User Question: ${user_message}
```

### Programmatic Configuration

```java
// Create prompt templates
PromptTemplate systemTemplate = new PromptTemplate(
    "custom_system",
    "You are {{agent_name}}, {{agent_description}}.\n\n" +
    "Current date and time: {{current_datetime}}\n\n" +
    "Special Instructions:\n" +
    "- Be creative and engaging\n" +
    "- Use the knowledge context: {{knowledge_context}}\n" +
    "{{custom_instructions}}",
    "Custom system prompt"
);

PromptTemplate userTemplate = new PromptTemplate(
    "custom_user",
    "{{knowledge_context}}User Request: {{user_message}}\n\n" +
    "Please provide a comprehensive response.",
    "Custom user prompt"
);

// Create agent with templates
AgentDefinition agent = new AgentDefinition(
    "creative-assistant",
    "Creative and engaging AI assistant",
    true,
    systemTemplate,
    userTemplate,
    "gpt-4o-mini",
    0.7,
    8000,
    List.of("rest-api"),
    config,
    0.8
);
```

## Pre-built Templates

### Default Templates

```java
// Default system template
PromptTemplate.defaultSystem()
// Renders to:
// "You are {{agent_name}}, {{agent_description}}.
//  Current date and time: {{current_datetime}}
//  Instructions:
//  - Be helpful, accurate, and concise
//  - If you don't know something, admit it
//  - Use the provided context when relevant
//  {{custom_instructions}}"

// Default user template  
PromptTemplate.defaultUser()
// Renders to:
// "{{knowledge_context}}User: {{user_message}}"
```

### RAG-Enabled Templates

```java
// RAG system template
PromptTemplate.ragSystem()
// Specialized for knowledge base integration

// RAG user template
PromptTemplate.ragUser()
// Formats knowledge context and user question
```

## Example Use Cases

### 1. Research Assistant

```yaml
research-agent:
  name: research-agent
  description: "Academic research specialist"
  prompt-templates:
    system: |
      You are {{agent_name}}, {{agent_description}}.
      
      Current date and time: {{current_datetime}}
      
      Research Guidelines:
      - Always cite sources when available
      - Provide multiple perspectives when relevant
      - Explain complex concepts clearly
      - Use the knowledge context as primary source material
      {{custom_instructions}}
    user: |
      {{knowledge_context}}Research Request: {{user_message}}
      
      Please provide a comprehensive response with citations if available.
```

### 2. Code Assistant

```yaml
coding-agent:
  name: coding-agent
  description: "Programming and development assistant"
  prompt-templates:
    system: |
      You are {{agent_name}}, {{agent_description}}.
      
      Current date and time: {{current_datetime}}
      
      Coding Guidelines:
      - Write clean, readable, and well-documented code
      - Explain your approach and reasoning
      - Include error handling when appropriate
      - Use the knowledge base for best practices
      {{custom_instructions}}
    user: |
      {{knowledge_context}}Coding Request: {{user_message}}
      
      Please provide a solution with code examples and explanations.
```

### 3. Customer Support

```yaml
support-agent:
  name: support-agent
  description: "Friendly customer support specialist"
  prompt-templates:
    system: |
      You are {{agent_name}}, {{agent_description}}.
      
      Current date and time: {{current_datetime}}
      
      Support Guidelines:
      - Be empathetic and understanding
      - Provide step-by-step solutions
      - Ask clarifying questions when needed
      - Use the knowledge base for accurate information
      {{custom_instructions}}
    user: |
      {{knowledge_context}}Customer Issue: {{user_message}}
      
      How can I help resolve this?
```

## Template Engine Features

### Variable Inspection

```java
PromptTemplate template = new PromptTemplate("test", "Hello {{name}}, today is {{date}}");

// Get all variables
String[] variables = template.getVariables(); // ["name", "date"]

// Check for specific variable
boolean hasName = template.hasVariable("name"); // true
```

### Dynamic Rendering

```java
Map<String, Object> variables = new HashMap<>();
variables.put("name", "Alice");
variables.put("date", "2024-01-15");

String rendered = template.render(variables);
// Result: "Hello Alice, today is 2024-01-15"
```

## Context Integration

### Knowledge Base Context

When using the knowledge base, the framework automatically populates `{{knowledge_context}}`:

```
{{knowledge_context}} becomes:
"Relevant context from knowledge base:
---
[Retrieved content from vector search]
---

"
```

### Custom Context Variables

Pass additional context through API calls:

```java
Map<String, Object> context = new HashMap<>();
context.put("user_preferences", "technical explanations");
context.put("session_id", "abc123");

// These become available as {{user_preferences}} and {{session_id}}
```

## Memory Integration

The framework supports two memory providers:

### 1. PostgreSQL Memory Provider (Default)
Uses your existing PostgreSQL database for storing agent memories:

```yaml
application:
  genai:
    memory:
      provider: postgres
      ttl-minutes: 60  # Memory expiration time
```

Features:
- Persistent storage
- Automatic cleanup of expired memories
- Efficient indexing and search
- Transaction support
- No additional infrastructure needed

### 2. Redis Memory Provider (Optional)
For high-performance caching needs:

```yaml
application:
  genai:
    memory:
      provider: redis
      ttl-minutes: 60
      redis:
        host: localhost
        port: 6379
        password:
        database: 0
```

Choose the provider based on your needs:
- Use PostgreSQL (default) for simplicity and persistence
- Use Redis for high-performance caching and distributed setups

## Best Practices

### 1. Template Design
- Keep templates focused and purpose-specific
- Use clear variable names
- Include fallback instructions
- Test with different context scenarios

### 2. Variable Usage
- Always provide default values for optional variables
- Use descriptive variable names
- Document expected variable types
- Handle missing variables gracefully

### 3. System vs User Templates
- **System templates**: Define agent personality, guidelines, capabilities
- **User templates**: Format user input, add context, structure queries

### 4. Knowledge Integration
- Always include `{{knowledge_context}}` in user templates for RAG
- Provide instructions on how to use knowledge context
- Handle cases where no relevant context is available

## Migration from Simple Prompts

### Before (Legacy)
```java
AgentDefinition agent = new AgentDefinition(
    "helper",
    "Helpful assistant",
    true,
    "You are a helpful assistant. Be friendly and accurate.", // Simple string
    model, temperature, maxTokens, tools, config, threshold
);
```

### After (Template-based)
```java
PromptTemplate systemTemplate = new PromptTemplate(
    "helper_system",
    "You are {{agent_name}}, {{agent_description}}.\n" +
    "Current time: {{current_datetime}}\n" +
    "Be friendly and accurate. {{custom_instructions}}"
);

PromptTemplate userTemplate = new PromptTemplate(
    "helper_user",
    "{{knowledge_context}}User: {{user_message}}"
);

AgentDefinition agent = new AgentDefinition(
    "helper",
    "Helpful assistant", 
    true,
    systemTemplate,
    userTemplate,
    model, temperature, maxTokens, tools, config, threshold
);
```

## Troubleshooting

### Common Issues

1. **Missing Variables**: Undefined variables render as empty strings
2. **Template Syntax**: Only `{{variable}}` syntax is supported (not `{variable}` or `$variable`)
3. **Configuration**: Ensure YAML indentation is correct for template blocks

### Debugging Templates

```java
// Check template variables
PromptTemplate template = agent.getSystemPromptTemplate();
logger.info("Template variables: {}", Arrays.toString(template.getVariables()));

// Test rendering with debug context
Map<String, Object> debugContext = buildTemplateVariables("test message", new HashMap<>());
String rendered = template.render(debugContext);
logger.info("Rendered template: {}", rendered);
```

---

The prompt template system provides powerful customization capabilities while maintaining backward compatibility with simple string prompts. Use templates to create sophisticated, context-aware agents that can adapt their behavior based on dynamic content and user needs. 