# AI Agent Framework API Guide

## Table of Contents
- [Introduction](#introduction)
- [Getting Started](#getting-started)
- [API Endpoints](#api-endpoints)
- [Agent Configuration](#agent-configuration)
- [Memory System](#memory-system)
- [Available Tools](#available-tools)
- [Example Usage](#example-usage)

## Introduction

The AI Agent Framework provides a flexible and extensible system for creating and managing AI agents with various capabilities. This guide covers the REST APIs, configuration options, and integration patterns for working with the framework.

## Getting Started

### Prerequisites
- Java 17 or higher
- Maven
- PostgreSQL (for production deployment)

### Basic Setup
1. Clone the repository
2. Configure application properties in `application.yml`
3. Run the application:
```bash
./mvnw spring-boot:run
```

## API Endpoints

### Agent Management

#### Start Chat Session
```http
POST /api/agents/chat
Content-Type: application/json

{
    "agentId": "dev-helper",
    "message": "How do I implement a new tool?",
    "metadata": {
        "key": "value"
    }
}
```

Response:
```json
{
    "response": "string",
    "tokens": [
        {
            "content": "string",
            "type": "string"
        }
    ],
    "metadata": {
        "key": "value"
    }
}
```

#### Manage Agent Memory
```http
POST /api/agents/memory
Content-Type: application/json

{
    "agentId": "dev-helper",
    "action": "CREATE",
    "memory": {
        "title": "string",
        "content": "string"
    }
}
```

## Agent Configuration

Agents are configured using YAML files located in the `src/main/resources/agents` directory.

Example configuration:
```yaml
id: dev-helper
name: Development Helper
description: Assists with development tasks and code analysis
model:
  type: GPT_4
  temperature: 0.7
tools:
  - FileReadTool
  - DataLakehouseApiTool
memory:
  enabled: true
  provider: postgres
```

### Available Agent Types
1. **dev-helper**: Development assistance and code analysis
2. **log-analyst**: Log file analysis and troubleshooting
3. **lakehouse-advisor**: Data lakehouse platform management
4. **weather-bot**: Weather information retrieval

## Memory System

The framework supports persistent memory for agents through different providers:

- **PostgreSQL**: Production-ready persistent storage
- **In-Memory**: For testing and development

### Memory Operations
- Create new memories
- Query existing memories
- Update memory content
- Delete outdated memories

## Available Tools

### File Operations
- **FileReadTool**: Read and analyze local files
  ```java
  // Example usage in agent configuration
  tools:
    - name: FileReadTool
      config:
        basePath: "/path/to/files"
  ```

### Data Lakehouse Integration
- **DataLakehouseApiTool**: Base API operations
- **LakehouseClusterTool**: Cluster management
- **LakehouseJobStatusTool**: Job status monitoring
- **LakehouseJobLogsTool**: Job logs retrieval

Configuration in `application.yml`:
```yaml
application:
  datalakehouse:
    url: "https://your-lakehouse-instance"
    token: "${LAKEHOUSE_TOKEN}"
```

## Example Usage

### Creating a Custom Agent

1. Create agent configuration file:
```yaml
# src/main/resources/agents/custom-agent.yml
id: custom-agent
name: Custom Agent
description: Description of your agent
model:
  type: GPT_4
tools:
  - FileReadTool
  - DataLakehouseApiTool
```

2. Start a chat session:
```bash
curl -X POST http://localhost:8080/api/agents/chat \
  -H "Content-Type: application/json" \
  -d '{
    "agentId": "custom-agent",
    "message": "Your instruction here"
  }'
```

### Using the Memory System

```bash
# Create a new memory
curl -X POST http://localhost:8080/api/agents/memory \
  -H "Content-Type: application/json" \
  -d '{
    "agentId": "custom-agent",
    "action": "CREATE",
    "memory": {
      "title": "Important Configuration",
      "content": "The system requires Java 17"
    }
  }'
```

## Best Practices

1. **Security**:
   - Never expose API tokens in code
   - Use environment variables for sensitive configuration
   - Implement proper authentication for production deployments

2. **Performance**:
   - Configure appropriate model parameters
   - Use memory system judiciously
   - Monitor tool execution times

3. **Development**:
   - Test agents thoroughly in development environment
   - Use the in-memory provider for testing
   - Follow the provided integration test patterns

## Troubleshooting

Common issues and solutions:

1. **Agent Not Found**
   - Verify agent configuration file exists
   - Check file permissions
   - Ensure correct agentId in requests

2. **Tool Execution Failures**
   - Verify tool configuration
   - Check required permissions
   - Review tool-specific logs

3. **Memory System Issues**
   - Verify database connectivity
   - Check memory provider configuration
   - Ensure proper schema initialization

## Contributing

1. Fork the repository
2. Create a feature branch
3. Implement changes with tests
4. Submit a pull request

For detailed contribution guidelines, see CONTRIBUTING.md. 