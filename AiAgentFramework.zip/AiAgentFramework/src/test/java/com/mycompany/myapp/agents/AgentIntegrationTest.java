package com.mycompany.myapp.agents;

import com.mycompany.myapp.IntegrationTest;
import com.mycompany.myapp.config.EmbeddedSQL;
import com.mycompany.myapp.config.TestConfiguration;
import com.mycompany.myapp.memory.Memory;
import com.mycompany.myapp.memory.MemoryProvider;
import com.mycompany.myapp.web.rest.AgentResource;
import com.mycompany.myapp.web.rest.vm.AgentChatRequest;
import com.mycompany.myapp.web.rest.vm.AgentChatResponse;
import com.mycompany.myapp.web.rest.vm.AgentMemoryRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
@EmbeddedSQL
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient
@ActiveProfiles("testdev")
@Import(TestConfiguration.class)
class AgentIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @Autowired
    private AgentRegistry agentRegistry;

    @Autowired
    private MemoryProvider memoryProvider;

    @Value("${application.genai.chat-model.api-key}")
    private String openaiApiKey;

    @DynamicPropertySource
    static void registerDynamicProperties(DynamicPropertyRegistry registry) {
        // Add any dynamic properties needed for tests
        registry.add("spring.docker.compose.skip.in-tests", () -> "true");
    }

    @BeforeEach
    void setUp() {
        // Skip tests if OpenAI API key is not configured
        org.junit.jupiter.api.Assumptions.assumeTrue(
            openaiApiKey != null && !openaiApiKey.isEmpty(),
            "OpenAI API key is required for these tests"
        );
    }

    @Test
    @WithMockUser(username = "test-user", authorities = {"ROLE_USER"})
    void testEndToEndAgentChat() {
        // First, store some test knowledge in memory
        Memory memory = memoryProvider.store(
            "test-knowledge",
            "The Earth is the third planet from the Sun and the only astronomical object known to harbor life.",
            LocalDateTime.now().plusHours(1)
        );

        // Create a chat request
        AgentChatRequest chatRequest = new AgentChatRequest();
        chatRequest.setAgentName("test-agent");
        chatRequest.setMessage("What is unique about Earth?");
        chatRequest.setIncludeMemoryContext(true);

        // Test the chat endpoint
        webTestClient.post()
            .uri("/api/agents/chat")
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(chatRequest), AgentChatRequest.class)
            .exchange()
            .expectStatus().isOk()
            .expectBody(AgentChatResponse.class)
            .value(response -> {
                assertThat(response.getMessage())
                    .isNotEmpty();
                assertThat(response.getAgentName()).isEqualTo("test-agent");
            });

        // Clean up the test memory
        memoryProvider.delete(memory.getId());
    }

    @Test
    @WithMockUser(username = "test-user", authorities = {"ROLE_USER"})
    void testMemoryOperations() {
        // Create a memory request
        AgentMemoryRequest memoryRequest = new AgentMemoryRequest();
        memoryRequest.setTitle("Important Fact");
        memoryRequest.setContent("OpenAI was founded in 2015.");
        memoryRequest.setTtlMinutes(60);

        // Test storing memory
        webTestClient.post()
            .uri("/api/agents/memory")
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(memoryRequest), AgentMemoryRequest.class)
            .exchange()
            .expectStatus().isOk()
            .expectBody(Memory.class)
            .value(memory -> {
                assertThat(memory.getId()).isNotEmpty();
                assertThat(memory.getTitle()).isEqualTo("Important Fact");
                assertThat(memory.getContent()).contains("OpenAI");
            });

        // Test memory search
        webTestClient.get()
            .uri(uriBuilder -> uriBuilder
                .path("/api/agents/memory/search")
                .queryParam("query", "OpenAI")
                .build())
            .exchange()
            .expectStatus().isOk()
            .expectBodyList(Memory.class)
            .value(memories -> {
                assertThat(memories).isNotEmpty();
                assertThat(memories.get(0).getContent()).contains("OpenAI");
            });
    }

    @Test
    @WithMockUser(username = "test-user", authorities = {"ROLE_USER"})
    void testAgentConfiguration() {
        // Test getting agent configuration
        webTestClient.get()
            .uri("/api/agents/config/test-agent")
            .exchange()
            .expectStatus().isOk()
            .expectBody(AgentDefinition.class)
            .value(definition -> {
                assertThat(definition.getName()).isEqualTo("test-agent");
                assertThat(definition.isEnabled()).isTrue();
                assertThat(definition.getModel()).isEqualTo("gpt-4");
                assertThat(definition.getPromptTemplates()).isNotNull();
                assertThat(definition.getPromptTemplates().get("system")).isNotNull();
                assertThat(definition.getPromptTemplates().get("user")).isNotNull();
            });

        // Test listing all agents
        webTestClient.get()
            .uri("/api/agents")
            .exchange()
            .expectStatus().isOk()
            .expectBodyList(AgentDefinition.class)
            .value(definitions -> {
                assertThat(definitions).isNotEmpty();
                assertThat(definitions)
                    .extracting(AgentDefinition::getName)
                    .contains("test-agent");
            });
    }

    @Test
    @WithMockUser(username = "test-user", authorities = {"ROLE_USER"})
    void testStreamingChat() {
        AgentChatRequest chatRequest = new AgentChatRequest();
        chatRequest.setAgentName("test-agent");
        chatRequest.setMessage("Write a short poem about AI.");
        chatRequest.setStreaming(true);

        // Test streaming chat endpoint
        webTestClient.post()
            .uri("/api/agents/chat/stream")
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(chatRequest), AgentChatRequest.class)
            .exchange()
            .expectStatus().isOk()
            .expectHeader().contentTypeCompatibleWith(MediaType.TEXT_EVENT_STREAM)
            .returnResult(String.class)
            .getResponseBody()
            .collectList()
            .block()  // Only for testing, don't use block() in production
            .forEach(chunk -> {
                assertThat(chunk).isNotEmpty();
                // Each chunk should be a valid SSE data field
                assertThat(chunk).startsWith("data:");
            });
    }

    @Test
    @WithMockUser(username = "test-user", authorities = {"ROLE_USER"})
    void testErrorHandling() {
        // Test with invalid agent name
        AgentChatRequest invalidRequest = new AgentChatRequest();
        invalidRequest.setAgentName("nonexistent-agent");
        invalidRequest.setMessage("Hello");

        webTestClient.post()
            .uri("/api/agents/chat")
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(invalidRequest), AgentChatRequest.class)
            .exchange()
            .expectStatus().isBadRequest();

        // Test with empty message
        AgentChatRequest emptyRequest = new AgentChatRequest();
        emptyRequest.setAgentName("test-agent");
        emptyRequest.setMessage("");

        webTestClient.post()
            .uri("/api/agents/chat")
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(emptyRequest), AgentChatRequest.class)
            .exchange()
            .expectStatus().isBadRequest();
    }
}
