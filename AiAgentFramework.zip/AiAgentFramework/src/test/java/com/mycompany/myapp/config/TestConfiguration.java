package com.mycompany.myapp.config;

import com.mycompany.myapp.agents.Agent;
import com.mycompany.myapp.agents.AgentDefinition;
import com.mycompany.myapp.agents.ConfigurableAgent;
import com.mycompany.myapp.memory.PostgresMemoryProvider;
import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import javax.sql.DataSource;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import com.mycompany.myapp.agents.AgentRegistry;
import com.mycompany.myapp.agents.InMemoryAgentRegistry;

@Configuration
@Profile("testdev")
@EnableAutoConfiguration(exclude = {
    DataSourceAutoConfiguration.class,
    DataSourceTransactionManagerAutoConfiguration.class,
    JdbcTemplateAutoConfiguration.class,
    LiquibaseAutoConfiguration.class,
    HibernateJpaAutoConfiguration.class
})
@ComponentScan(
    basePackages = "com.mycompany.myapp",
    excludeFilters = {
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, classes = com.mycompany.myapp.agents.DefaultAgentRegistry.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, classes = com.mycompany.myapp.embeddings.OpenAiEmbeddingProvider.class)
    }
)
@EnableWebFluxSecurity
public class TestConfiguration {
    
    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
        http
            .csrf(csrf -> csrf.disable())
            .authorizeExchange(auth -> auth.anyExchange().permitAll());
        return http.build();
    }

    @Bean
    @Primary
    public DataSource dataSource() {
        return new EmbeddedDatabaseBuilder()
            .setType(EmbeddedDatabaseType.H2)
            .build();
    }

    @Bean
    @Primary
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    @Primary
    public ChatModel testChatModel() {
        return new ChatModel() {
            @Override
            public String chat(String prompt) {
                return "Test response: " + prompt;
            }
        };
    }
    
    @Bean
    @Primary
    public Agent testAgent(ChatModel chatModel) {
        Map<String, String> promptTemplates = new HashMap<>();
        promptTemplates.put("system", "You are a helpful AI assistant named test-agent. You are being used in integration tests.");
        promptTemplates.put("user", "{{user_message}}\n{{#knowledge_context}}Using this relevant knowledge:\n{{knowledge_context}}{{/knowledge_context}}");
        
        AgentDefinition definition = new AgentDefinition();
        definition.setName("test-agent");
        definition.setDescription("A test agent for integration tests");
        definition.setEnabled(true);
        definition.setModel("gpt-4");
        definition.setTemperature(0.1);
        definition.setMaxTokens(1000);
        definition.setPromptTemplates(promptTemplates);
        
        return new ConfigurableAgent(definition, chatModel);
    }

    @Bean
    @Primary
    public AgentRegistry testAgentRegistry(ChatModel chatModel, Agent testAgent) {
        InMemoryAgentRegistry registry = new InMemoryAgentRegistry(chatModel);
        registry.registerAgent(testAgent);
        return registry;
    }
} 