package com.mycompany.myapp.memory;

import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Component
@Primary
@Profile("testdev")
public class InMemoryTestMemoryProvider implements MemoryProvider {
    
    private final Map<String, Memory> memories = new ConcurrentHashMap<>();
    
    @Override
    public Memory store(String title, String content, LocalDateTime expiresAt) {
        String id = UUID.randomUUID().toString();
        Memory memory = new Memory(id, title, content, LocalDateTime.now(), expiresAt);
        memories.put(id, memory);
        return memory;
    }
    
    @Override
    public Optional<Memory> retrieve(String id) {
        Memory memory = memories.get(id);
        if (memory == null || (memory.getExpiresAt() != null && memory.getExpiresAt().isBefore(LocalDateTime.now()))) {
            return Optional.empty();
        }
        return Optional.of(memory);
    }
    
    @Override
    public List<Memory> findByTitle(String title) {
        return memories.values().stream()
            .filter(m -> m.getTitle().equals(title))
            .filter(m -> m.getExpiresAt() == null || m.getExpiresAt().isAfter(LocalDateTime.now()))
            .collect(Collectors.toList());
    }
    
    @Override
    public List<Memory> searchContent(String query) {
        return memories.values().stream()
            .filter(m -> m.getContent().toLowerCase().contains(query.toLowerCase()))
            .filter(m -> m.getExpiresAt() == null || m.getExpiresAt().isAfter(LocalDateTime.now()))
            .collect(Collectors.toList());
    }
    
    @Override
    public void delete(String id) {
        memories.remove(id);
    }
    
    @Override
    public void update(String id, String title, String content, LocalDateTime expiresAt) {
        if (!memories.containsKey(id)) {
            throw new IllegalArgumentException("Memory not found: " + id);
        }
        Memory oldMemory = memories.get(id);
        Memory updatedMemory = new Memory(
            id,
            title,
            content,
            oldMemory.getCreatedAt(),
            expiresAt
        );
        memories.put(id, updatedMemory);
    }
    
    @Override
    public void cleanup() {
        LocalDateTime now = LocalDateTime.now();
        memories.entrySet().removeIf(entry -> 
            entry.getValue().getExpiresAt() != null && 
            entry.getValue().getExpiresAt().isBefore(now)
        );
    }
} 