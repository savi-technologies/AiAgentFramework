package com.mycompany.myapp.embeddings;

import dev.langchain4j.data.document.Document;
import reactor.core.publisher.Flux;

/**
 * Interface for loading documents from various sources.
 */
public interface DocumentLoader {
    
    /**
     * Loads all documents from the configured source.
     * 
     * @return a Flux of documents
     */
    Flux<Document> loadDocuments();
    
    /**
     * Loads a specific document by its identifier.
     * 
     * @param documentId the document identifier
     * @return a Flux containing the document if found
     */
    Flux<Document> loadDocument(String documentId);
    
    /**
     * Checks if the loader supports the given source type.
     * 
     * @param sourceType the source type (e.g., "filesystem", "database", "s3")
     * @return true if supported, false otherwise
     */
    boolean supports(String sourceType);
    
    /**
     * Gets the name of this document loader.
     * 
     * @return the loader name
     */
    String getLoaderName();
} 