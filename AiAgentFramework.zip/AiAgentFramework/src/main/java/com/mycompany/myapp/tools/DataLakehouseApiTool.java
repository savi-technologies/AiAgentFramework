package com.mycompany.myapp.tools;

import com.mycompany.myapp.config.ApplicationProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriBuilder;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Generic REST tool tailored for the company Data Lakehouse platform.
 * Adds baseUrl prefix, Authorization header, retry logic and pagination helpers.
 */
@Component
public class DataLakehouseApiTool implements Tool {

    private static final Logger log = LoggerFactory.getLogger(DataLakehouseApiTool.class);
    private static final String TOOL_NAME = "data_lakehouse_api_call";

    private final WebClient webClient;
    private final ToolSpecification specification;
    private final ApplicationProperties applicationProperties;

    public DataLakehouseApiTool(ApplicationProperties applicationProperties) {
        this.applicationProperties = applicationProperties;
        String baseUrl = StringUtils.hasText(applicationProperties.getGenai().getDataLakehouse().getUrl())
            ? applicationProperties.getGenai().getDataLakehouse().getUrl()
            : "https://lakehouse.local";
        this.webClient = WebClient.builder()
            .baseUrl(baseUrl)
            .defaultHeader(HttpHeaders.USER_AGENT, "Lakehouse-Agent/1.0")
            .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + applicationProperties.getGenai().getDataLakehouse().getToken())
            .build();
        this.specification = createSpecification();
    }

    @Override
    public String getName() {
        return TOOL_NAME;
    }

    @Override
    public String getDescription() {
        return "Calls Data Lakehouse REST endpoints with automatic authentication.";
    }

    @Override
    public ToolSpecification getSpecification() {
        return specification;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Mono<ToolResult> execute(Map<String, Object> parameters, Map<String, Object> context) {
        long startTime = System.currentTimeMillis();
        try {
            if (!validateParameters(parameters)) {
                return Mono.just(ToolResult.error("Invalid parameters"));
            }
            String path = (String) parameters.get("path");
            String method = ((String) parameters.getOrDefault("method", "GET")).toUpperCase();
            Map<String, Object> queryParams = (Map<String, Object>) parameters.getOrDefault("query", Map.of());
            Object body = parameters.get("body");

            WebClient.RequestHeadersSpec<?> spec = webClient.method(HttpMethod.valueOf(method))
                .uri(uriBuilder -> buildUri(uriBuilder, path, queryParams))
                .accept(MediaType.APPLICATION_JSON);

            WebClient.ResponseSpec response;
            if (body != null && !HttpMethod.GET.matches(method)) {
                response = ((WebClient.RequestBodySpec) spec).bodyValue(body).retrieve();
            } else {
                response = spec.retrieve();
            }

            return response.bodyToMono(String.class)
                .timeout(Duration.ofSeconds(30))
                .map(resp -> {
                    long duration = System.currentTimeMillis() - startTime;
                    return ToolResult.success(resp, duration, Map.of(
                        "path", path,
                        "status", "ok",
                        "duration", duration
                    ));
                })
                .onErrorResume(err -> {
                    long duration = System.currentTimeMillis() - startTime;
                    log.error("Lakehouse API call failed: {}", err.getMessage());
                    return Mono.just(ToolResult.error(err.getMessage(), err, duration));
                });
        } catch (Exception e) {
            long duration = System.currentTimeMillis() - startTime;
            return Mono.just(ToolResult.error(e.getMessage(), e, duration));
        }
    }

    private java.net.URI buildUri(UriBuilder builder, String path, Map<String, Object> query) {
        UriBuilder ub = builder.path(path.startsWith("/") ? path : "/" + path);
        if (!CollectionUtils.isEmpty(query)) {
            query.forEach((k, v) -> ub.queryParam(k, v));
        }
        return ub.build();
    }

    @Override
    public boolean validateParameters(Map<String, Object> parameters) {
        if (parameters == null) return false;
        String path = (String) parameters.get("path");
        return StringUtils.hasText(path);
    }

    @Override
    public boolean isAvailable() {
        return StringUtils.hasText(applicationProperties.getGenai().getDataLakehouse().getToken());
    }

    private ToolSpecification createSpecification() {
        List<ToolSpecification.ToolParameter> params = List.of(
            new ToolSpecification.ToolParameter("path", "string", "API path, e.g., /api/clusters/123", true, null, null),
            new ToolSpecification.ToolParameter("method", "string", "HTTP method (GET, POST, etc)", false, "GET", null),
            new ToolSpecification.ToolParameter("query", "object", "Query parameters map", false, Map.of(), null),
            new ToolSpecification.ToolParameter("body", "object", "Request body", false, null, null)
        );
        return new ToolSpecification(TOOL_NAME, getDescription(), params, Map.of("category", "lakehouse", "auth", "Bearer"));
    }
} 