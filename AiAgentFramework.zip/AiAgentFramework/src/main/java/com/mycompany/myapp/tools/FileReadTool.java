package com.mycompany.myapp.tools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

/**
 * Tool that reads the content of a local file (e.g., log file) and returns it as a string.
 * This is useful for agents who need to inspect application logs or other text files on disk.
 */
@Component
public class FileReadTool implements Tool {

    private static final Logger logger = LoggerFactory.getLogger(FileReadTool.class);
    private static final String TOOL_NAME = "file_read";

    private final ToolSpecification specification;

    public FileReadTool() {
        this.specification = createSpecification();
    }

    @Override
    public String getName() {
        return TOOL_NAME;
    }

    @Override
    public String getDescription() {
        return "Reads the content of a local file and returns it as text";
    }

    @Override
    public ToolSpecification getSpecification() {
        return specification;
    }

    @Override
    public Mono<ToolResult> execute(Map<String, Object> parameters, Map<String, Object> context) {
        long startTime = System.currentTimeMillis();

        return Mono.fromCallable(() -> {
            if (!validateParameters(parameters)) {
                return ToolResult.error("Invalid parameters provided");
            }
            String filePath = (String) parameters.get("filePath");
            int maxBytes = ((Number) parameters.getOrDefault("maxBytes", 65536)).intValue(); // default 64 KB

            Path path = Paths.get(filePath);
            logger.debug("Reading file: {} (maxBytes={})", filePath, maxBytes);
            if (!Files.exists(path) || !Files.isRegularFile(path)) {
                return ToolResult.error("File does not exist: " + filePath);
            }
            if (Files.size(path) == 0) {
                return ToolResult.success("");
            }

            byte[] bytes = Files.readAllBytes(path);
            String content = new String(bytes, StandardCharsets.UTF_8);
            if (content.length() > maxBytes) {
                content = content.substring(content.length() - maxBytes); // return last part
            }

            long executionTime = System.currentTimeMillis() - startTime;
            return ToolResult.success(content, executionTime, Map.of(
                "filePath", filePath,
                "bytesRead", content.length()
            ));
        }).onErrorResume(IOException.class, e -> {
            long executionTime = System.currentTimeMillis() - startTime;
            logger.error("Failed to read file: {}", e.getMessage(), e);
            return Mono.just(ToolResult.error("Failed to read file: " + e.getMessage(), e, executionTime));
        });
    }

    @Override
    public boolean validateParameters(Map<String, Object> parameters) {
        if (parameters == null) {
            return false;
        }
        String filePath = (String) parameters.get("filePath");
        return StringUtils.hasText(filePath);
    }

    @Override
    public boolean isAvailable() {
        return true; // Always available
    }

    private ToolSpecification createSpecification() {
        List<ToolSpecification.ToolParameter> params = List.of(
            new ToolSpecification.ToolParameter(
                "filePath",
                "string",
                "Absolute or relative path to the file to read",
                true,
                null,
                null
            ),
            new ToolSpecification.ToolParameter(
                "maxBytes",
                "integer",
                "Maximum number of bytes to return (default 65536). If the file is larger, the tail is returned.",
                false,
                65536,
                Map.of("minimum", 1024, "maximum", 1048576)
            )
        );

        return new ToolSpecification(TOOL_NAME, getDescription(), params, Map.of("category", "filesystem"));
    }
} 