package com.mycompany.myapp.chat;

/**
 * Enum for supported chat model types.
 */
public enum ChatModelType {
    OPENAI,
    ANTHROPIC,
    GOOGLE,
    AZURE_OPENAI
} 