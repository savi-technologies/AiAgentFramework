package com.mycompany.myapp.agents;

import org.springframework.util.StringUtils;

import java.util.Map;
import java.util.StringJoiner;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * String template processor that supports both Java string templates and Mustache-style variables.
 */
public class StringTemplate {
    
    private static final Pattern TEMPLATE_PATTERN = Pattern.compile("\\$\\{([^}]+)}|\\{\\{([^}]+)}}");
    
    private final String template;
    private final String name;
    private final String description;
    
    public StringTemplate(String name, String template, String description) {
        this.name = name;
        this.template = template;
        this.description = description;
    }
    
    public StringTemplate(String name, String template) {
        this(name, template, null);
    }
    
    /**
     * Renders the template by replacing variables with provided values.
     * Supports both ${variable} and {{variable}} syntax.
     * 
     * @param variables the variables to substitute
     * @return the rendered template
     */
    public String render(Map<String, Object> variables) {
        if (variables == null) {
            return template;
        }
        
        StringBuffer result = new StringBuffer();
        Matcher matcher = TEMPLATE_PATTERN.matcher(template);
        
        while (matcher.find()) {
            String varName = matcher.group(1) != null ? matcher.group(1) : matcher.group(2);
            Object value = variables.get(varName);
            String replacement = value != null ? value.toString() : "";
            matcher.appendReplacement(result, Matcher.quoteReplacement(replacement));
        }
        
        matcher.appendTail(result);
        return result.toString();
    }
    
    /**
     * Gets all variable names used in this template.
     * 
     * @return array of variable names
     */
    public String[] getVariables() {
        if (template == null) {
            return new String[0];
        }
        
        StringJoiner joiner = new StringJoiner(",");
        Matcher matcher = TEMPLATE_PATTERN.matcher(template);
        
        while (matcher.find()) {
            String variableName = matcher.group(1) != null ? matcher.group(1) : matcher.group(2);
            joiner.add(variableName.trim());
        }
        
        return joiner.toString().split(",");
    }
    
    /**
     * Checks if the template contains the specified variable.
     * 
     * @param variableName the variable name to check
     * @return true if the variable exists in the template
     */
    public boolean hasVariable(String variableName) {
        if (template == null) {
            return false;
        }
        
        return TEMPLATE_PATTERN.matcher(template)
                .results()
                .map(matchResult -> matchResult.group(1) != null ? 
                        matchResult.group(1).trim() : matchResult.group(2).trim())
                .anyMatch(var -> var.equals(variableName));
    }
    
    /**
     * Creates a simple template with just the provided text (no variables).
     * 
     * @param name the template name
     * @param text the template text
     * @return a new StringTemplate
     */
    public static StringTemplate simple(String name, String text) {
        return new StringTemplate(name, text);
    }
    
    /**
     * Creates a default system prompt template using string template syntax.
     * 
     * @return a default system prompt template
     */
    public static StringTemplate defaultSystem() {
        return new StringTemplate(
            "default_system",
            "You are ${agent_name}, ${agent_description}.\n\n" +
            "Current date and time: ${current_datetime}\n\n" +
            "Instructions:\n" +
            "- Provide clear, accurate, and helpful responses\n" +
            "- If you don't know something, admit it honestly\n" +
            "- Use the provided knowledge context when relevant\n" +
            "- Be concise but thorough",
            "Default system prompt template"
        );
    }
    
    /**
     * Creates a default user prompt template using string template syntax.
     * 
     * @return a default user prompt template
     */
    public static StringTemplate defaultUser() {
        return new StringTemplate(
            "default_user",
            "${knowledge_context}User: ${user_message}",
            "Default user prompt template"
        );
    }
    
    /**
     * Creates a RAG (Retrieval Augmented Generation) system prompt template.
     * 
     * @return a RAG system prompt template
     */
    public static StringTemplate ragSystem() {
        return new StringTemplate(
            "rag_system",
            """
            You are ${agent_name}, ${agent_description}.
            
            You have access to a knowledge base. When answering questions, use the provided context from the knowledge base when relevant.
            
            Guidelines:
            - Always prioritize accuracy over speed
            - If the context doesn't contain relevant information, rely on your general knowledge
            - Cite specific information when using the provided context
            - If you're unsure about something, say so
            
            ${custom_instructions}
            """,
            "RAG-enabled system prompt"
        );
    }
    
    public String getName() {
        return name;
    }
    
    public String getTemplate() {
        return template;
    }
    
    public String getDescription() {
        return description;
    }
    
    @Override
    public String toString() {
        return "StringTemplate{" +
                "name='" + name + '\'' +
                ", variables=" + java.util.Arrays.toString(getVariables()) +
                '}';
    }
} 