package com.mycompany.myapp.web.rest.vm;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

/**
 * View Model object for agent chat requests.
 */
public class AgentChatRequest {
    
    @NotNull
    @NotEmpty
    private String agentName;
    
    @NotNull
    @NotEmpty
    private String message;
    
    private boolean includeMemoryContext = true;
    
    private boolean streaming = false;
    
    public String getAgentName() {
        return agentName;
    }
    
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public boolean isIncludeMemoryContext() {
        return includeMemoryContext;
    }
    
    public void setIncludeMemoryContext(boolean includeMemoryContext) {
        this.includeMemoryContext = includeMemoryContext;
    }
    
    public boolean isStreaming() {
        return streaming;
    }
    
    public void setStreaming(boolean streaming) {
        this.streaming = streaming;
    }
    
    @Override
    public String toString() {
        return "AgentChatRequest{" +
            "agentName='" + agentName + '\'' +
            ", message='" + message + '\'' +
            ", includeMemoryContext=" + includeMemoryContext +
            ", streaming=" + streaming +
            '}';
    }
} 