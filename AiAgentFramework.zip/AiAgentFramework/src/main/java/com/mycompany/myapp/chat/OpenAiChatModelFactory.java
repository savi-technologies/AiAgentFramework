package com.mycompany.myapp.chat;

import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class OpenAiChatModelFactory {
    
    @Value("${application.genai.chat-model.api-key}")
    private String apiKey;
    
    @Value("${application.genai.chat-model.model}")
    private String model;
    
    @Value("${application.genai.chat-model.temperature}")
    private Double temperature;
    
    @Value("${application.genai.chat-model.max-tokens}")
    private Integer maxTokens;
    
    @Value("${application.genai.chat-model.timeout-seconds}")
    private Integer timeoutSeconds;
    
    public ChatModel createChatModel() {
        return OpenAiChatModel.builder()
            .apiKey(apiKey)
            .modelName(model)
            .temperature(temperature)
            .maxTokens(maxTokens)
            .timeout(java.time.Duration.ofSeconds(timeoutSeconds))
            .build();
    }
} 