package com.mycompany.myapp.web.rest.vm;

/**
 * View Model object for agent chat responses.
 */
public class AgentChatResponse {
    
    private String agentName;
    private String message;
    private String conversationId;
    private boolean streaming;
    
    public AgentChatResponse() {
    }
    
    public AgentChatResponse(String agentName, String message) {
        this.agentName = agentName;
        this.message = message;
    }
    
    public String getAgentName() {
        return agentName;
    }
    
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getConversationId() {
        return conversationId;
    }
    
    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }
    
    public boolean isStreaming() {
        return streaming;
    }
    
    public void setStreaming(boolean streaming) {
        this.streaming = streaming;
    }
    
    @Override
    public String toString() {
        return "AgentChatResponse{" +
            "agentName='" + agentName + '\'' +
            ", message='" + message + '\'' +
            ", conversationId='" + conversationId + '\'' +
            ", streaming=" + streaming +
            '}';
    }
} 