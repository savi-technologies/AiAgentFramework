package com.mycompany.myapp.chat;

import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.chat.StreamingChatModel;

/**
 * Factory interface for creating chat models from different providers.
 */
public interface ChatModelFactory {
    
    /**
     * Creates a chat language model for the specified provider.
     * 
     * @param provider the chat model provider
     * @param apiKey the API key for the provider
     * @param model the model name to use
     * @param temperature the temperature setting for the model
     * @param maxTokens the maximum number of tokens
     * @param timeoutSeconds the timeout in seconds
     * @return a configured ChatLanguageModel
     */
    ChatModel createChatModel(
        ChatModelType provider,
        String apiKey,
        String model,
        Double temperature,
        Integer maxTokens,
        Integer timeoutSeconds
    );
    
    /**
     * Creates a streaming chat language model for the specified provider.
     * 
     * @param provider the chat model provider
     * @param apiKey the API key for the provider
     * @param model the model name to use
     * @param temperature the temperature setting for the model
     * @param maxTokens the maximum number of tokens
     * @param timeoutSeconds the timeout in seconds
     * @return a configured StreamingChatModel
     */
    StreamingChatModel createStreamingChatModel(
        ChatModelType provider,
        String apiKey,
        String model,
        Double temperature,
        Integer maxTokens,
        Integer timeoutSeconds
    );
    
    /**
     * Checks if the factory supports the given provider.
     * 
     * @param provider the chat model provider
     * @return true if supported, false otherwise
     */
    boolean supports(ChatModelType provider);
} 