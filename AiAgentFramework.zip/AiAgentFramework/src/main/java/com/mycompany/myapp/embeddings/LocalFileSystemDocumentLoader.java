package com.mycompany.myapp.embeddings;

import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.document.loader.FileSystemDocumentLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Document loader implementation for loading documents from the local file system.
 */
@Component
public class LocalFileSystemDocumentLoader implements DocumentLoader {
    
    private static final Logger logger = LoggerFactory.getLogger(LocalFileSystemDocumentLoader.class);
    
    private final String documentsPath;
    
    public LocalFileSystemDocumentLoader() {
        this.documentsPath = "src/main/resources/documents"; // Default path
        ensureDirectoryExists();
    }
    
    public LocalFileSystemDocumentLoader(String documentsPath) {
        this.documentsPath = documentsPath;
        ensureDirectoryExists();
    }
    
    private void ensureDirectoryExists() {
        try {
            Path dir = Paths.get(documentsPath).toAbsolutePath().normalize();
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
                logger.info("Created documents directory: {}", dir);
            }
            
            // Check if directory is readable
            if (!Files.isReadable(dir)) {
                logger.error("Documents directory is not readable: {}", dir);
                throw new IllegalStateException("Documents directory is not readable: " + dir);
            }
        } catch (IOException e) {
            logger.error("Failed to create or check documents directory: {}", documentsPath, e);
            throw new IllegalStateException("Failed to initialize documents directory", e);
        }
    }
    
    @Override
    public Flux<Document> loadDocuments() {
        return Flux.defer(() -> {
            try {
                Path documentsDir = Paths.get(documentsPath).toAbsolutePath().normalize();
                
                if (!Files.exists(documentsDir)) {
                    logger.warn("Documents directory does not exist: {}", documentsPath);
                    return Flux.empty();
                }
                
                if (!Files.isDirectory(documentsDir)) {
                    logger.error("Path is not a directory: {}", documentsPath);
                    return Flux.error(new IllegalArgumentException("Path is not a directory: " + documentsPath));
                }
                
                // Create a list of files first to avoid stream issues
                List<Path> files = Files.walk(documentsDir)
                    .filter(Files::isRegularFile)
                    .filter(this::isSupportedFileType)
                    .collect(Collectors.toList());
                
                return Flux.fromIterable(files)
                    .map(this::loadDocumentFromPath)
                    .onErrorContinue((error, path) -> {
                        logger.error("Error loading document from path: {}", path, error);
                    });
                
            } catch (IOException e) {
                logger.error("Error loading documents from: {}", documentsPath, e);
                return Flux.error(e);
            }
        });
    }
    
    @Override
    public Flux<Document> loadDocument(String documentId) {
        return Flux.defer(() -> {
            try {
                Path documentPath = Paths.get(documentsPath, documentId);
                
                if (!Files.exists(documentPath) || !Files.isRegularFile(documentPath)) {
                    logger.warn("Document not found: {}", documentPath);
                    return Flux.empty();
                }
                
                if (!isSupportedFileType(documentPath)) {
                    logger.warn("Unsupported file type: {}", documentPath);
                    return Flux.empty();
                }
                
                Document document = loadDocumentFromPath(documentPath);
                return Flux.just(document);
                
            } catch (Exception e) {
                logger.error("Error loading document: {}", documentId, e);
                return Flux.error(e);
            }
        });
    }
    
    @Override
    public boolean supports(String sourceType) {
        return "filesystem".equals(sourceType) || "local".equals(sourceType);
    }
    
    @Override
    public String getLoaderName() {
        return "LocalFileSystemDocumentLoader";
    }
    
    private boolean isSupportedFileType(Path path) {
        String fileName = path.getFileName().toString().toLowerCase();
        return fileName.endsWith(".txt") || 
               fileName.endsWith(".md") || 
               fileName.endsWith(".pdf") ||
               fileName.endsWith(".docx") ||
               fileName.endsWith(".html");
    }
    
    private Document loadDocumentFromPath(Path path) {
        try {
            // Use LangChain4j's FileSystemDocumentLoader
            return FileSystemDocumentLoader.loadDocument(path);
        } catch (Exception e) {
            logger.error("Error loading document from path: {}", path, e);
            throw new RuntimeException("Failed to load document: " + path, e);
        }
    }
} 