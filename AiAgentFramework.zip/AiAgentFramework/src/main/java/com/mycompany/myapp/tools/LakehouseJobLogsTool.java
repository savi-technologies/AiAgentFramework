package com.mycompany.myapp.tools;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * Tool that fetches driver logs tail for a Lakehouse job run.
 */
@Component
public class LakehouseJobLogsTool implements Tool {

    private static final String NAME = "dlh_get_job_logs";
    private final DataLakehouseApiTool apiTool;
    private final ToolSpecification spec;

    public LakehouseJobLogsTool(DataLakehouseApiTool apiTool) {
        this.apiTool = apiTool;
        this.spec = buildSpec();
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String getDescription() {
        return "Returns the last portion of driver logs for a specific job run.";
    }

    @Override
    public ToolSpecification getSpecification() {
        return spec;
    }

    @Override
    public Mono<ToolResult> execute(Map<String, Object> parameters, Map<String, Object> context) {
        if (!validateParameters(parameters)) {
            return Mono.just(ToolResult.error("jobId and runId are required"));
        }
        String jobId = (String) parameters.get("jobId");
        String runId = (String) parameters.get("runId");
        int tailKb = ((Number) parameters.getOrDefault("tailKb", 64)).intValue();

        Map<String, Object> params = Map.of(
            "path", "/api/jobs/" + jobId + "/runs/" + runId + "/logs",
            "method", "GET",
            "query", Map.of("tailKb", tailKb)
        );
        return apiTool.execute(params, context);
    }

    @Override
    public boolean validateParameters(Map<String, Object> parameters) {
        if (parameters == null) return false;
        String jobId = (String) parameters.get("jobId");
        String runId = (String) parameters.get("runId");
        return StringUtils.hasText(jobId) && StringUtils.hasText(runId);
    }

    @Override
    public boolean isAvailable() {
        return apiTool.isAvailable();
    }

    private ToolSpecification buildSpec() {
        List<ToolSpecification.ToolParameter> params = List.of(
            new ToolSpecification.ToolParameter("jobId", "string", "Job identifier", true, null, null),
            new ToolSpecification.ToolParameter("runId", "string", "Run identifier", true, null, null),
            new ToolSpecification.ToolParameter("tailKb", "integer", "Kilobytes from log end to fetch (default 64)", false, 64, Map.of("minimum", 1, "maximum", 1024))
        );
        return new ToolSpecification(NAME, getDescription(), params, Map.of("category", "lakehouse"));
    }
} 