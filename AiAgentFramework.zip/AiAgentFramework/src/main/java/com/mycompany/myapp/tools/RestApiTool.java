package com.mycompany.myapp.tools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tool for making REST API calls to external services.
 */
@Component
public class RestApiTool implements Tool {
    
    private static final Logger logger = LoggerFactory.getLogger(RestApiTool.class);
    private static final String TOOL_NAME = "rest_api_call";
    
    private final WebClient webClient;
    private final ToolSpecification specification;
    
    public RestApiTool() {
        this.webClient = WebClient.builder()
            .defaultHeader(HttpHeaders.USER_AGENT, "GenAI-Platform-Agent/1.0")
            .build();
        this.specification = createSpecification();
    }
    
    @Override
    public String getName() {
        return TOOL_NAME;
    }
    
    @Override
    public String getDescription() {
        return "Makes HTTP requests to external REST APIs";
    }
    
    @Override
    public ToolSpecification getSpecification() {
        return specification;
    }
    
    @Override
    public Mono<ToolResult> execute(Map<String, Object> parameters, Map<String, Object> context) {
        long startTime = System.currentTimeMillis();
        
        try {
            // Validate parameters
            if (!validateParameters(parameters)) {
                return Mono.just(ToolResult.error("Invalid parameters provided"));
            }
            
            String url = (String) parameters.get("url");
            String method = (String) parameters.getOrDefault("method", "GET");
            String body = (String) parameters.get("body");
            @SuppressWarnings("unchecked")
            Map<String, String> headers = (Map<String, String>) parameters.getOrDefault("headers", new HashMap<>());
            
            logger.debug("Making {} request to: {}", method, url);
            
            // Build the request
            WebClient.RequestHeadersSpec<?> requestSpec = webClient
                .method(HttpMethod.valueOf(method.toUpperCase()))
                .uri(url)
                .headers(httpHeaders -> {
                    headers.forEach(httpHeaders::set);
                    if (!headers.containsKey(HttpHeaders.CONTENT_TYPE) && StringUtils.hasText(body)) {
                        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
                    }
                });
            
            // Add body if present
            WebClient.ResponseSpec responseSpec;
            if (StringUtils.hasText(body) && !HttpMethod.GET.name().equals(method.toUpperCase())) {
                responseSpec = ((WebClient.RequestBodySpec) requestSpec).bodyValue(body).retrieve();
            } else {
                responseSpec = requestSpec.retrieve();
            }
            
            // Execute the request
            return responseSpec
                .bodyToMono(String.class)
                .timeout(Duration.ofSeconds(30))
                .map(response -> {
                    long executionTime = System.currentTimeMillis() - startTime;
                    logger.debug("REST API call completed in {}ms", executionTime);
                    
                    Map<String, Object> metadata = new HashMap<>();
                    metadata.put("url", url);
                    metadata.put("method", method);
                    metadata.put("responseLength", response.length());
                    
                    return ToolResult.success(response, executionTime, metadata);
                })
                .onErrorResume(error -> {
                    long executionTime = System.currentTimeMillis() - startTime;
                    logger.error("REST API call failed: {}", error.getMessage(), error);
                    return Mono.just(ToolResult.error("API call failed: " + error.getMessage(), error, executionTime));
                });
                
        } catch (Exception e) {
            long executionTime = System.currentTimeMillis() - startTime;
            logger.error("Error executing REST API tool: {}", e.getMessage(), e);
            return Mono.just(ToolResult.error("Tool execution failed: " + e.getMessage(), e, executionTime));
        }
    }
    
    @Override
    public boolean validateParameters(Map<String, Object> parameters) {
        if (parameters == null || parameters.isEmpty()) {
            return false;
        }
        
        // URL is required
        String url = (String) parameters.get("url");
        if (!StringUtils.hasText(url)) {
            return false;
        }
        
        // Method must be valid HTTP method if provided
        String method = (String) parameters.get("method");
        if (StringUtils.hasText(method)) {
            try {
                HttpMethod.valueOf(method.toUpperCase());
            } catch (IllegalArgumentException e) {
                return false;
            }
        }
        
        return true;
    }
    
    @Override
    public boolean isAvailable() {
        return true; // Always available
    }
    
    private ToolSpecification createSpecification() {
        List<ToolSpecification.ToolParameter> parameters = List.of(
            new ToolSpecification.ToolParameter(
                "url", 
                "string", 
                "The URL to make the request to", 
                true, 
                null, 
                Map.of("format", "uri")
            ),
            new ToolSpecification.ToolParameter(
                "method", 
                "string", 
                "HTTP method (GET, POST, PUT, DELETE, etc.)", 
                false, 
                "GET", 
                Map.of("enum", List.of("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"))
            ),
            new ToolSpecification.ToolParameter(
                "headers", 
                "object", 
                "HTTP headers to include in the request", 
                false, 
                new HashMap<>(), 
                null
            ),
            new ToolSpecification.ToolParameter(
                "body", 
                "string", 
                "Request body (for POST, PUT, etc.)", 
                false, 
                null, 
                null
            )
        );
        
        Map<String, Object> metadata = Map.of(
            "category", "network",
            "timeout", 30,
            "description", "Makes HTTP requests to external REST APIs with support for various methods and headers"
        );
        
        return new ToolSpecification(TOOL_NAME, getDescription(), parameters, metadata);
    }
} 