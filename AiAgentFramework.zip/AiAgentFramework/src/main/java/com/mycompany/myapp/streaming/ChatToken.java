package com.mycompany.myapp.streaming;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.Instant;
import java.util.List;

/**
 * Represents a chat token in a streaming response.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatToken {
    private final String type;
    private final String content;
    private String tool;
    private Status status;
    private String message;
    private List<String> citations;
    private final Instant timestamp;
    
    public ChatToken(String type, String content) {
        this.type = type;
        this.content = content;
        this.timestamp = Instant.now();
    }
    
    public static ChatToken progress(String tool, Status status, String message) {
        ChatToken token = new ChatToken("progress", message);
        token.tool = tool;
        token.status = status;
        return token;
    }
    
    public static ChatToken token(String content) {
        return new ChatToken("token", content);
    }
    
    public static ChatToken finalResult(String content, List<String> citations) {
        ChatToken token = new ChatToken("final", content);
        token.citations = citations;
        return token;
    }
    
    public static ChatToken error(String message) {
        return new ChatToken("error", message);
    }
    
    public String getType() {
        return type;
    }
    
    public String getContent() {
        return content;
    }
    
    public String getTool() {
        return tool;
    }
    
    public Status getStatus() {
        return status;
    }
    
    public String getMessage() {
        return message;
    }
    
    public List<String> getCitations() {
        return citations;
    }
    
    public Instant getTimestamp() {
        return timestamp;
    }
    
    public enum Status {
        START,
        IN_PROGRESS,
        COMPLETE,
        ERROR
    }
} 