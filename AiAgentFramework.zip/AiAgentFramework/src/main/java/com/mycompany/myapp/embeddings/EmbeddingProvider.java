package com.mycompany.myapp.embeddings;

import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.embedding.Embedding;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Interface for embedding providers that can generate embeddings from text and documents.
 */
public interface EmbeddingProvider {
    
    /**
     * Generates an embedding for a single text.
     * 
     * @param text the text to embed
     * @return a Mono containing the embedding
     */
    Mono<Embedding> embed(String text);
    
    /**
     * Generates embeddings for multiple texts.
     * 
     * @param texts the texts to embed
     * @return a Flux of embeddings
     */
    Flux<Embedding> embedBatch(List<String> texts);
    
    /**
     * Gets the dimension of embeddings produced by this provider.
     * 
     * @return the embedding dimension
     */
    int getDimension();
    
    /**
     * Gets the name of this embedding provider.
     * 
     * @return the provider name
     */
    String getProviderName();
} 