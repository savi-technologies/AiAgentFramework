package com.mycompany.myapp.tools;

import java.util.List;
import java.util.Map;

/**
 * Specification of a tool including its parameters and metadata.
 */
public class ToolSpecification {
    
    private String name;
    private String description;
    private List<ToolParameter> parameters;
    private Map<String, Object> metadata;
    
    public ToolSpecification() {}
    
    public ToolSpecification(String name, String description, List<ToolParameter> parameters, Map<String, Object> metadata) {
        this.name = name;
        this.description = description;
        this.parameters = parameters;
        this.metadata = metadata;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public List<ToolParameter> getParameters() {
        return parameters;
    }
    
    public void setParameters(List<ToolParameter> parameters) {
        this.parameters = parameters;
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    @Override
    public String toString() {
        return "ToolSpecification{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", parameters=" + parameters +
                '}';
    }
    
    /**
     * Represents a tool parameter with its name, type, and constraints.
     */
    public static class ToolParameter {
        private String name;
        private String type;
        private String description;
        private boolean required;
        private Object defaultValue;
        private Map<String, Object> constraints;
        
        public ToolParameter() {}
        
        public ToolParameter(String name, String type, String description, boolean required, Object defaultValue, Map<String, Object> constraints) {
            this.name = name;
            this.type = type;
            this.description = description;
            this.required = required;
            this.defaultValue = defaultValue;
            this.constraints = constraints;
        }
        
        public String getName() {
            return name;
        }
        
        public void setName(String name) {
            this.name = name;
        }
        
        public String getType() {
            return type;
        }
        
        public void setType(String type) {
            this.type = type;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
        
        public boolean isRequired() {
            return required;
        }
        
        public void setRequired(boolean required) {
            this.required = required;
        }
        
        public Object getDefaultValue() {
            return defaultValue;
        }
        
        public void setDefaultValue(Object defaultValue) {
            this.defaultValue = defaultValue;
        }
        
        public Map<String, Object> getConstraints() {
            return constraints;
        }
        
        public void setConstraints(Map<String, Object> constraints) {
            this.constraints = constraints;
        }
        
        @Override
        public String toString() {
            return "ToolParameter{" +
                    "name='" + name + '\'' +
                    ", type='" + type + '\'' +
                    ", required=" + required +
                    '}';
        }
    }
} 