/**
 * Webflux database column mapper.
 */
package com.mycompany.myapp.repository.rowmapper;
