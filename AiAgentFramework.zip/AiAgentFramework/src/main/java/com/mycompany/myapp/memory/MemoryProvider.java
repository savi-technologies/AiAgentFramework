package com.mycompany.myapp.memory;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Interface for memory storage providers.
 */
public interface MemoryProvider {
    
    /**
     * Stores a new memory.
     *
     * @param title the memory title
     * @param content the memory content
     * @param expiresAt optional expiration time
     * @return the stored memory
     */
    Memory store(String title, String content, LocalDateTime expiresAt);
    
    /**
     * Retrieves a memory by ID.
     *
     * @param id the memory ID
     * @return the memory if found and not expired
     */
    Optional<Memory> retrieve(String id);
    
    /**
     * Finds memories by title.
     *
     * @param title the title to search for
     * @return list of matching memories
     */
    List<Memory> findByTitle(String title);
    
    /**
     * Searches memory content.
     *
     * @param query the search query
     * @return list of matching memories
     */
    List<Memory> searchContent(String query);
    
    /**
     * Deletes a memory.
     *
     * @param id the memory ID
     */
    void delete(String id);
    
    /**
     * Updates an existing memory.
     *
     * @param id the memory ID
     * @param title the new title
     * @param content the new content
     * @param expiresAt the new expiration time
     */
    void update(String id, String title, String content, LocalDateTime expiresAt);
    
    /**
     * Cleans up expired memories.
     */
    void cleanup();
} 