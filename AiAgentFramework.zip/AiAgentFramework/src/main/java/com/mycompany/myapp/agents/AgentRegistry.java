package com.mycompany.myapp.agents;

import java.util.List;
import java.util.Optional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Registry for managing AI agents and their lifecycle.
 */
public interface AgentRegistry {
    
    /**
     * Gets an agent by name asynchronously.
     * 
     * @param name the name of the agent
     * @return a Mono containing the agent if found
     */
    Mono<Agent> getAgentAsync(String name);
    
    /**
     * Gets an agent by name (blocking).
     *
     * @param name the agent name
     * @return Optional containing the agent if found
     */
    Optional<Agent> getAgent(String name);
    
    /**
     * Gets an agent definition by name asynchronously.
     * 
     * @param name the name of the agent
     * @return a Mono containing the agent definition if found
     */
    Mono<AgentDefinition> getAgentDefinitionAsync(String name);
    
    /**
     * Gets an agent definition by name (blocking).
     *
     * @param name the agent name
     * @return Optional containing the agent definition if found
     */
    Optional<AgentDefinition> getAgentDefinition(String name);
    
    /**
     * Gets all registered and enabled agents asynchronously.
     * 
     * @return a Flux of enabled agent definitions
     */
    Flux<AgentDefinition> getEnabledAgents();
    
    /**
     * Gets all registered agents asynchronously (enabled and disabled).
     * 
     * @return a Flux of all agent definitions
     */
    Flux<AgentDefinition> getAllAgentsAsync();
    
    /**
     * Gets all registered agent definitions (blocking).
     *
     * @return list of all agent definitions
     */
    List<AgentDefinition> getAllAgentDefinitions();
    
    /**
     * Get or create an agent from a definition.
     *
     * @param definition the agent definition
     * @return the agent instance
     */
    Agent getOrCreateAgent(AgentDefinition definition);
    
    /**
     * Registers an agent definition asynchronously.
     * 
     * @param definition the agent definition to register
     * @return a Mono indicating completion
     */
    Mono<Void> registerAgentAsync(AgentDefinition definition);
    
    /**
     * Register a new agent (blocking).
     *
     * @param agent the agent to register
     */
    void registerAgent(Agent agent);
    
    /**
     * Removes an agent from the registry asynchronously.
     * 
     * @param name the name of the agent to remove
     * @return a Mono indicating completion
     */
    Mono<Void> removeAgentAsync(String name);
    
    /**
     * Unregister an agent (blocking).
     *
     * @param name the name of the agent to unregister
     */
    void unregisterAgent(String name);
    
    /**
     * Reloads agent configurations from the configured source.
     * 
     * @return a Mono indicating completion
     */
    Mono<Void> reloadAgents();
    
    /**
     * Checks if an agent is registered and enabled.
     * 
     * @param name the name of the agent
     * @return a Mono containing true if the agent is available
     */
    Mono<Boolean> isAgentAvailable(String name);
} 