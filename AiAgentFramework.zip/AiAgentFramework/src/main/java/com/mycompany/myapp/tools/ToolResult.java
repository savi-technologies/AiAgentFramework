package com.mycompany.myapp.tools;

import java.time.Instant;
import java.util.Map;

/**
 * Result of tool execution containing the output and metadata.
 */
public class ToolResult {
    
    public enum Status {
        SUCCESS("success"),
        ERROR("error"),
        TIMEOUT("timeout"),
        CANCELLED("cancelled");
        
        private final String value;
        
        Status(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
    }
    
    private Status status;
    private Object result;
    private String errorMessage;
    private Throwable error;
    private Instant timestamp;
    private long executionTimeMs;
    private Map<String, Object> metadata;
    
    public ToolResult() {
        this.timestamp = Instant.now();
    }
    
    public ToolResult(Status status, Object result, String errorMessage, Throwable error, long executionTimeMs, Map<String, Object> metadata) {
        this();
        this.status = status;
        this.result = result;
        this.errorMessage = errorMessage;
        this.error = error;
        this.executionTimeMs = executionTimeMs;
        this.metadata = metadata;
    }
    
    public static ToolResult success(Object result) {
        return new ToolResult(Status.SUCCESS, result, null, null, 0, null);
    }
    
    public static ToolResult success(Object result, long executionTimeMs) {
        return new ToolResult(Status.SUCCESS, result, null, null, executionTimeMs, null);
    }
    
    public static ToolResult success(Object result, long executionTimeMs, Map<String, Object> metadata) {
        return new ToolResult(Status.SUCCESS, result, null, null, executionTimeMs, metadata);
    }
    
    public static ToolResult error(String errorMessage) {
        return new ToolResult(Status.ERROR, null, errorMessage, null, 0, null);
    }
    
    public static ToolResult error(String errorMessage, Throwable error) {
        return new ToolResult(Status.ERROR, null, errorMessage, error, 0, null);
    }
    
    public static ToolResult error(String errorMessage, Throwable error, long executionTimeMs) {
        return new ToolResult(Status.ERROR, null, errorMessage, error, executionTimeMs, null);
    }
    
    public static ToolResult timeout(long executionTimeMs) {
        return new ToolResult(Status.TIMEOUT, null, "Tool execution timed out", null, executionTimeMs, null);
    }
    
    public static ToolResult cancelled() {
        return new ToolResult(Status.CANCELLED, null, "Tool execution was cancelled", null, 0, null);
    }
    
    public Status getStatus() {
        return status;
    }
    
    public void setStatus(Status status) {
        this.status = status;
    }
    
    public Object getResult() {
        return result;
    }
    
    public void setResult(Object result) {
        this.result = result;
    }
    
    public String getErrorMessage() {
        return errorMessage;
    }
    
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    
    public Throwable getError() {
        return error;
    }
    
    public void setError(Throwable error) {
        this.error = error;
    }
    
    public Instant getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(Instant timestamp) {
        this.timestamp = timestamp;
    }
    
    public long getExecutionTimeMs() {
        return executionTimeMs;
    }
    
    public void setExecutionTimeMs(long executionTimeMs) {
        this.executionTimeMs = executionTimeMs;
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    public boolean isSuccess() {
        return status == Status.SUCCESS;
    }
    
    public boolean isError() {
        return status == Status.ERROR;
    }
    
    @Override
    public String toString() {
        return "ToolResult{" +
                "status=" + status +
                ", result=" + result +
                ", errorMessage='" + errorMessage + '\'' +
                ", executionTimeMs=" + executionTimeMs +
                ", timestamp=" + timestamp +
                '}';
    }
} 