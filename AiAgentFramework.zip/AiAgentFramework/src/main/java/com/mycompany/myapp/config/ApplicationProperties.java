package com.mycompany.myapp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

import java.util.HashMap;
import java.util.Map;

/**
 * Properties specific to Ai Agent Framework.
 * <p>
 * Properties are configured in the {@code application.yml} file.
 */
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {
    
    @NestedConfigurationProperty
    private GenAi genai = new GenAi();
    
    public GenAi getGenai() {
        return genai;
    }
    
    public void setGenai(GenAi genai) {
        this.genai = genai;
    }
    
    public static class GenAi {
        @NestedConfigurationProperty
        private ChatModel chatModel = new ChatModel();
        
        @NestedConfigurationProperty
        private Embeddings embeddings = new Embeddings();
        
        @NestedConfigurationProperty
        private Agents agents = new Agents();
        
        @NestedConfigurationProperty
        private Memory memory = new Memory();
        
        @NestedConfigurationProperty
        private KnowledgeBase knowledgeBase = new KnowledgeBase();
        
        @NestedConfigurationProperty
        private DataLakehouse dataLakehouse = new DataLakehouse();
        
        public ChatModel getChatModel() {
            return chatModel;
        }
        
        public void setChatModel(ChatModel chatModel) {
            this.chatModel = chatModel;
        }
        
        public Embeddings getEmbeddings() {
            return embeddings;
        }
        
        public void setEmbeddings(Embeddings embeddings) {
            this.embeddings = embeddings;
        }
        
        public Agents getAgents() {
            return agents;
        }
        
        public void setAgents(Agents agents) {
            this.agents = agents;
        }
        
        public Memory getMemory() {
            return memory;
        }
        
        public void setMemory(Memory memory) {
            this.memory = memory;
        }
        
        public KnowledgeBase getKnowledgeBase() {
            return knowledgeBase;
        }
        
        public void setKnowledgeBase(KnowledgeBase knowledgeBase) {
            this.knowledgeBase = knowledgeBase;
        }
        
        public DataLakehouse getDataLakehouse() {
            return dataLakehouse;
        }
        
        public void setDataLakehouse(DataLakehouse dataLakehouse) {
            this.dataLakehouse = dataLakehouse;
        }
    }
    
    public static class ChatModel {
        private String provider = "openai";
        private String model = "gpt-4o-mini";
        private String apiKey;
        private Double temperature = 0.1;
        private Integer maxTokens = 8000;
        private Integer timeoutSeconds = 30;
        
        public String getProvider() {
            return provider;
        }
        
        public void setProvider(String provider) {
            this.provider = provider;
        }
        
        public String getModel() {
            return model;
        }
        
        public void setModel(String model) {
            this.model = model;
        }
        
        public String getApiKey() {
            return apiKey;
        }
        
        public void setApiKey(String apiKey) {
            this.apiKey = apiKey;
        }
        
        public Double getTemperature() {
            return temperature;
        }
        
        public void setTemperature(Double temperature) {
            this.temperature = temperature;
        }
        
        public Integer getMaxTokens() {
            return maxTokens;
        }
        
        public void setMaxTokens(Integer maxTokens) {
            this.maxTokens = maxTokens;
        }
        
        public Integer getTimeoutSeconds() {
            return timeoutSeconds;
        }
        
        public void setTimeoutSeconds(Integer timeoutSeconds) {
            this.timeoutSeconds = timeoutSeconds;
        }
    }
    
    public static class Embeddings {
        private String provider = "openai";
        private String model = "text-embedding-ada-002";
        private String apiKey;
        private String documentsPath = "src/main/resources/documents";
        
        public String getProvider() {
            return provider;
        }
        
        public void setProvider(String provider) {
            this.provider = provider;
        }
        
        public String getModel() {
            return model;
        }
        
        public void setModel(String model) {
            this.model = model;
        }
        
        public String getApiKey() {
            return apiKey;
        }
        
        public void setApiKey(String apiKey) {
            this.apiKey = apiKey;
        }
        
        public String getDocumentsPath() {
            return documentsPath;
        }
        
        public void setDocumentsPath(String documentsPath) {
            this.documentsPath = documentsPath;
        }
    }
    
    public static class Agents {
        private boolean enabled = true;
        private String configPath = "classpath:agents";
        private Map<String, AgentConfiguration> configurations = new HashMap<>();
        
        public boolean isEnabled() {
            return enabled;
        }
        
        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
        
        public String getConfigPath() {
            return configPath;
        }
        
        public void setConfigPath(String configPath) {
            this.configPath = configPath;
        }
        
        public Map<String, AgentConfiguration> getConfigurations() {
            return configurations;
        }
        
        public void setConfigurations(Map<String, AgentConfiguration> configurations) {
            this.configurations = configurations;
        }
    }
    
    public static class AgentConfiguration {
        private String name;
        private String description;
        private boolean enabled = true;
        private String model;
        private Double temperature;
        private Integer maxTokens;
        private Map<String, String> promptTemplates = new HashMap<>();
        private Map<String, Object> configuration = new HashMap<>();
        
        public String getName() {
            return name;
        }
        
        public void setName(String name) {
            this.name = name;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
        
        public boolean isEnabled() {
            return enabled;
        }
        
        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
        
        public String getModel() {
            return model;
        }
        
        public void setModel(String model) {
            this.model = model;
        }
        
        public Double getTemperature() {
            return temperature;
        }
        
        public void setTemperature(Double temperature) {
            this.temperature = temperature;
        }
        
        public Integer getMaxTokens() {
            return maxTokens;
        }
        
        public void setMaxTokens(Integer maxTokens) {
            this.maxTokens = maxTokens;
        }
        
        public Map<String, String> getPromptTemplates() {
            return promptTemplates;
        }
        
        public void setPromptTemplates(Map<String, String> promptTemplates) {
            this.promptTemplates = promptTemplates;
        }
        
        public Map<String, Object> getConfiguration() {
            return configuration;
        }
        
        public void setConfiguration(Map<String, Object> configuration) {
            this.configuration = configuration;
        }
    }
    
    public static class Memory {
        private String provider = "redis";
        private int ttlMinutes = 60;
        
        public String getProvider() {
            return provider;
        }
        
        public void setProvider(String provider) {
            this.provider = provider;
        }
        
        public int getTtlMinutes() {
            return ttlMinutes;
        }
        
        public void setTtlMinutes(int ttlMinutes) {
            this.ttlMinutes = ttlMinutes;
        }
    }
    
    public static class KnowledgeBase {
        /** Whether to automatically index documents on application startup (true by default). */
        private boolean autoIndex = true;
        private int maxSearchResults = 10;
        private double minSimilarityThreshold = 0.7;
        
        public boolean isAutoIndex() {
            return autoIndex;
        }
        
        public void setAutoIndex(boolean autoIndex) {
            this.autoIndex = autoIndex;
        }
        
        public int getMaxSearchResults() {
            return maxSearchResults;
        }
        
        public void setMaxSearchResults(int maxSearchResults) {
            this.maxSearchResults = maxSearchResults;
        }
        
        public double getMinSimilarityThreshold() {
            return minSimilarityThreshold;
        }
        
        public void setMinSimilarityThreshold(double minSimilarityThreshold) {
            this.minSimilarityThreshold = minSimilarityThreshold;
        }
    }

    /**
     * Connection info for the company Data Lakehouse control plane (e.g., token-secured REST APIs).
     */
    public static class DataLakehouse {
        /** Base URL such as https://lakehouse.acme.com */
        private String url;

        /** Personal-access token or Bearer token for API auth. */
        private String token;

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }
    }
}
