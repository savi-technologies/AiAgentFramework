/**
 * Rest layer visual models.
 */
package com.mycompany.myapp.web.rest.vm;
