package com.mycompany.myapp.agents;

import java.util.List;
import java.util.Map;

/**
 * Interface for AI agents.
 */
public interface Agent {
    
    /**
     * Gets the agent's definition.
     *
     * @return the agent definition
     */
    AgentDefinition getDefinition();
    
    /**
     * Gets the agent's name.
     *
     * @return the agent name
     */
    default String getName() {
        return getDefinition().getName();
    }
    
    /**
     * Checks if the agent is enabled.
     *
     * @return true if enabled, false otherwise
     */
    default boolean isEnabled() {
        return getDefinition().isEnabled();
    }
    
    /**
     * Chat with the agent.
     *
     * @param context the chat context
     * @return the agent's response
     */
    String chat(Map<String, Object> context);
    
    /**
     * Chat with the agent in streaming mode.
     *
     * @param context the chat context
     * @return list of response tokens
     */
    List<String> streamChat(Map<String, Object> context);
} 