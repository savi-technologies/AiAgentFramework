package com.mycompany.myapp.agents;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Represents a prompt template with support for variable substitution.
 */
public class PromptTemplate {
    
    private static final Pattern VARIABLE_PATTERN = Pattern.compile("\\{\\{([^}]+)\\}\\}");
    
    private final String template;
    private final String name;
    private final String description;
    
    public PromptTemplate(String name, String template, String description) {
        this.name = name;
        this.template = template;
        this.description = description;
    }
    
    public PromptTemplate(String name, String template) {
        this(name, template, null);
    }
    
    /**
     * Renders the template by replacing variables with provided values.
     * Variables in the template should be in the format {{variableName}}.
     * 
     * @param variables the variables to substitute
     * @return the rendered template
     */
    public String render(Map<String, Object> variables) {
        if (template == null) {
            return "";
        }
        
        String result = template;
        Matcher matcher = VARIABLE_PATTERN.matcher(template);
        
        while (matcher.find()) {
            String variableName = matcher.group(1).trim();
            Object value = variables.get(variableName);
            String replacement = value != null ? value.toString() : "";
            
            // Replace the variable placeholder with the actual value
            result = result.replace("{{" + variableName + "}}", replacement);
        }
        
        return result;
    }
    
    /**
     * Gets all variable names used in this template.
     * 
     * @return array of variable names
     */
    public String[] getVariables() {
        if (template == null) {
            return new String[0];
        }
        
        return VARIABLE_PATTERN.matcher(template)
                .results()
                .map(matchResult -> matchResult.group(1).trim())
                .distinct()
                .toArray(String[]::new);
    }
    
    /**
     * Checks if the template contains the specified variable.
     * 
     * @param variableName the variable name to check
     * @return true if the variable exists in the template
     */
    public boolean hasVariable(String variableName) {
        return template != null && template.contains("{{" + variableName + "}}");
    }
    
    /**
     * Creates a simple template with just the provided text (no variables).
     * 
     * @param name the template name
     * @param text the template text
     * @return a new PromptTemplate
     */
    public static PromptTemplate simple(String name, String text) {
        return new PromptTemplate(name, text);
    }
    
    /**
     * Creates a default system prompt template.
     * 
     * @return a default system prompt template
     */
    public static PromptTemplate defaultSystem() {
        return new PromptTemplate(
            "default_system",
            "You are {{agent_name}}, {{agent_description}}.\n\n" +
            "Current date and time: {{current_datetime}}\n" +
            "{{additional_context}}\n\n" +
            "Instructions:\n" +
            "- Be helpful, accurate, and concise\n" +
            "- If you don't know something, admit it\n" +
            "- Use the provided context when relevant\n" +
            "{{custom_instructions}}",
            "Default system prompt with agent context"
        );
    }
    
    /**
     * Creates a default user prompt template.
     * 
     * @return a default user prompt template
     */
    public static PromptTemplate defaultUser() {
        return new PromptTemplate(
            "default_user",
            "{{knowledge_context}}" +
            "User: {{user_message}}",
            "Default user prompt with knowledge context"
        );
    }
    
    /**
     * Creates a RAG (Retrieval Augmented Generation) system prompt template.
     * 
     * @return a RAG system prompt template
     */
    public static PromptTemplate ragSystem() {
        return new PromptTemplate(
            "rag_system",
            "You are {{agent_name}}, {{agent_description}}.\n\n" +
            "You have access to a knowledge base. When answering questions, use the provided context from the knowledge base when relevant.\n\n" +
            "Guidelines:\n" +
            "- Always prioritize accuracy over speed\n" +
            "- If the context doesn't contain relevant information, rely on your general knowledge\n" +
            "- Cite specific information when using the provided context\n" +
            "- If you're unsure about something, say so\n\n" +
            "{{custom_instructions}}",
            "RAG-enabled system prompt"
        );
    }
    
    /**
     * Creates a RAG user prompt template.
     * 
     * @return a RAG user prompt template
     */
    public static PromptTemplate ragUser() {
        return new PromptTemplate(
            "rag_user",
            "{{knowledge_context}}" +
            "User Question: {{user_message}}",
            "RAG user prompt with knowledge context"
        );
    }
    
    public String getName() {
        return name;
    }
    
    public String getTemplate() {
        return template;
    }
    
    public String getDescription() {
        return description;
    }
    
    @Override
    public String toString() {
        return "PromptTemplate{" +
                "name='" + name + '\'' +
                ", variables=" + java.util.Arrays.toString(getVariables()) +
                '}';
    }
} 