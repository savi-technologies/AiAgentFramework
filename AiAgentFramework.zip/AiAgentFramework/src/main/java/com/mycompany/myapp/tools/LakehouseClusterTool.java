package com.mycompany.myapp.tools;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * Tool that fetches Lakehouse compute-cluster details by clusterId.
 */
@Component
public class LakehouseClusterTool implements Tool {

    private static final String NAME = "dlh_get_cluster";
    private final DataLakehouseApiTool apiTool;
    private final ToolSpecification spec;

    public LakehouseClusterTool(DataLakehouseApiTool apiTool) {
        this.apiTool = apiTool;
        this.spec = buildSpec();
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String getDescription() {
        return "Returns Lakehouse cluster details for the given clusterId.";
    }

    @Override
    public ToolSpecification getSpecification() {
        return spec;
    }

    @Override
    public Mono<ToolResult> execute(Map<String, Object> parameters, Map<String, Object> context) {
        if (!validateParameters(parameters)) {
            return Mono.just(ToolResult.error("clusterId is required"));
        }
        String clusterId = (String) parameters.get("clusterId");
        Map<String, Object> params = Map.of(
            "path", "/api/clusters/" + clusterId,
            "method", "GET"
        );
        return apiTool.execute(params, context);
    }

    @Override
    public boolean validateParameters(Map<String, Object> parameters) {
        String clusterId = parameters != null ? (String) parameters.get("clusterId") : null;
        return StringUtils.hasText(clusterId);
    }

    @Override
    public boolean isAvailable() {
        return apiTool.isAvailable();
    }

    private ToolSpecification buildSpec() {
        List<ToolSpecification.ToolParameter> params = List.of(
            new ToolSpecification.ToolParameter("clusterId", "string", "Cluster identifier", true, null, null)
        );
        return new ToolSpecification(NAME, getDescription(), params, Map.of("category", "lakehouse"));
    }
} 