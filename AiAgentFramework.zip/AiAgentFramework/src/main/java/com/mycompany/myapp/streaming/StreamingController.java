package com.mycompany.myapp.streaming;

import com.mycompany.myapp.agents.Agent;
import com.mycompany.myapp.agents.AgentRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * REST controller for streaming chat responses.
 */
@RestController
@RequestMapping("/api/streaming")
public class StreamingController {
    
    private static final Logger log = LoggerFactory.getLogger(StreamingController.class);
    
    private final AgentRegistry agentRegistry;
    
    public StreamingController(AgentRegistry agentRegistry) {
        this.agentRegistry = agentRegistry;
    }
    
    /**
     * Stream chat response from an agent.
     *
     * @param agentName the name of the agent
     * @param context the chat context
     * @return flux of server-sent events containing chat tokens
     */
    @PostMapping(value = "/chat/{agentName}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<ServerSentEvent<ChatToken>> streamChat(
        @PathVariable String agentName,
        @RequestBody Map<String, Object> context
    ) {
        return agentRegistry.getAgentAsync(agentName)
            .switchIfEmpty(Mono.error(new IllegalArgumentException("Agent not found: " + agentName)))
            .flatMapMany(agent -> {
                if (!agent.isEnabled()) {
                    return Flux.error(new IllegalStateException("Agent is not enabled: " + agentName));
                }
                
                return Flux.fromIterable(agent.streamChat(context))
                    .map(token -> ServerSentEvent.<ChatToken>builder()
                        .event("token")
                        .data(new ChatToken("token", token))
                        .build()
                    )
                    .concatWith(Flux.just(ServerSentEvent.<ChatToken>builder()
                        .event("complete")
                        .data(new ChatToken("complete", "Chat completed"))
                        .build()
                    ));
            })
            .onErrorResume(error -> {
                log.error("Error in streaming chat: {}", error.getMessage(), error);
                return Flux.just(ServerSentEvent.<ChatToken>builder()
                    .event("error")
                    .data(new ChatToken("error", error.getMessage()))
                    .build()
                );
            });
    }
    
    /**
     * Get a non-streaming chat response from an agent.
     *
     * @param agentName the name of the agent
     * @param context the chat context
     * @return mono containing the chat response
     */
    @PostMapping("/chat/{agentName}/sync")
    public Mono<ChatResponse> syncChat(
        @PathVariable String agentName,
        @RequestBody Map<String, Object> context
    ) {
        return agentRegistry.getAgentAsync(agentName)
            .switchIfEmpty(Mono.error(new IllegalArgumentException("Agent not found: " + agentName)))
            .flatMap(agent -> {
                if (!agent.isEnabled()) {
                    return Mono.error(new IllegalStateException("Agent is not enabled: " + agentName));
                }
                
                return Mono.just(new ChatResponse(agent.chat(context)));
            })
            .onErrorResume(error -> {
                log.error("Error in sync chat: {}", error.getMessage(), error);
                return Mono.just(new ChatResponse(error.getMessage()));
            });
    }
    
    /**
     * Response wrapper for sync chat.
     */
    public static class ChatResponse {
        private final String response;
        
        public ChatResponse(String response) {
            this.response = response;
        }
        
        public String getResponse() {
            return response;
        }
    }
} 