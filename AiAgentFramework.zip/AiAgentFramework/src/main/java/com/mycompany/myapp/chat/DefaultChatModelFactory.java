package com.mycompany.myapp.chat;

import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.chat.StreamingChatModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.model.openai.OpenAiStreamingChatModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Duration;

/**
 * Default implementation of ChatModelFactory that creates OpenAI chat models.
 */
@Component
public class DefaultChatModelFactory implements ChatModelFactory {
    
    private static final Logger log = LoggerFactory.getLogger(DefaultChatModelFactory.class);
    
    @Override
    public ChatModel createChatModel(
        ChatModelType provider,
        String apiKey,
        String model,
        Double temperature,
        Integer maxTokens,
        Integer timeoutSeconds
    ) {
        if (!supports(provider)) {
            throw new IllegalArgumentException("Unsupported chat model provider: " + provider);
        }
        
        log.debug("Creating chat model with provider: {}, model: {}", provider, model);
        
        return OpenAiChatModel.builder()
            .apiKey(apiKey)
            .modelName(model)
            .temperature(temperature)
            .maxTokens(maxTokens)
            .timeout(Duration.ofSeconds(timeoutSeconds))
            .build();
    }
    
    @Override
    public StreamingChatModel createStreamingChatModel(
        ChatModelType provider,
        String apiKey,
        String model,
        Double temperature,
        Integer maxTokens,
        Integer timeoutSeconds
    ) {
        if (!supports(provider)) {
            throw new IllegalArgumentException("Unsupported chat model provider: " + provider);
        }
        
        log.debug("Creating streaming chat model with provider: {}, model: {}", provider, model);
        
        return OpenAiStreamingChatModel.builder()
            .apiKey(apiKey)
            .modelName(model)
            .temperature(temperature)
            .maxTokens(maxTokens)
            .timeout(Duration.ofSeconds(timeoutSeconds))
            .build();
    }
    
    @Override
    public boolean supports(ChatModelType provider) {
        return provider == ChatModelType.OPENAI;
    }
} 