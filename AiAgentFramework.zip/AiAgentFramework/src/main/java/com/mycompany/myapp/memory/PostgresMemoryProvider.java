package com.mycompany.myapp.memory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * PostgreSQL-based implementation of memory storage.
 */
@Component
public class PostgresMemoryProvider implements MemoryProvider {
    
    private static final Logger logger = LoggerFactory.getLogger(PostgresMemoryProvider.class);
    
    private final JdbcTemplate jdbcTemplate;
    
    @Autowired
    public PostgresMemoryProvider(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    
    @PostConstruct
    public void init() {
        createTableIfNotExists();
    }
    
    private void createTableIfNotExists() {
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS agent_memory (
                id UUID PRIMARY KEY,
                title VARCHAR(255) NOT NULL,
                content TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL,
                expires_at TIMESTAMP,
                metadata JSONB
            )
        """);
        
        // Create index on title for faster lookups
        jdbcTemplate.execute(
            "CREATE INDEX IF NOT EXISTS idx_agent_memory_title ON agent_memory(title)"
        );
    }
    
    @Override
    @Transactional
    public Memory store(String title, String content, LocalDateTime expiresAt) {
        String id = UUID.randomUUID().toString();
        LocalDateTime now = LocalDateTime.now();
        
        jdbcTemplate.update(
            "INSERT INTO agent_memory (id, title, content, created_at, expires_at) VALUES (?, ?, ?, ?, ?)",
            id, title, content, now, expiresAt
        );
        
        return new Memory(id, title, content, now, expiresAt);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Optional<Memory> retrieve(String id) {
        try {
            return Optional.ofNullable(
                jdbcTemplate.queryForObject(
                    "SELECT * FROM agent_memory WHERE id = ? AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP())",
                    this::mapRowToMemory,
                    id
                )
            );
        } catch (Exception e) {
            logger.debug("Memory not found or expired: {}", id);
            return Optional.empty();
        }
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Memory> findByTitle(String title) {
        return jdbcTemplate.query(
            "SELECT * FROM agent_memory WHERE title = ? AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP())",
            this::mapRowToMemory,
            title
        );
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Memory> searchContent(String query) {
        String likePattern = "%" + query + "%";
        return jdbcTemplate.query(
            "SELECT * FROM agent_memory WHERE LOWER(content) LIKE LOWER(?) AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP())",
            this::mapRowToMemory,
            likePattern
        );
    }
    
    @Override
    @Transactional
    public void delete(String id) {
        jdbcTemplate.update("DELETE FROM agent_memory WHERE id = ?", id);
    }
    
    @Override
    @Transactional
    public void update(String id, String title, String content, LocalDateTime expiresAt) {
        int updated = jdbcTemplate.update(
            "UPDATE agent_memory SET title = ?, content = ?, expires_at = ? WHERE id = ?",
            title, content, expiresAt, id
        );
        
        if (updated == 0) {
            throw new IllegalArgumentException("Memory not found: " + id);
        }
    }
    
    @Override
    @Transactional
    public void cleanup() {
        jdbcTemplate.update("DELETE FROM agent_memory WHERE expires_at < CURRENT_TIMESTAMP()");
    }
    
    private Memory mapRowToMemory(ResultSet rs, int rowNum) throws SQLException {
        return new Memory(
            rs.getString("id"),
            rs.getString("title"),
            rs.getString("content"),
            rs.getTimestamp("created_at").toLocalDateTime(),
            rs.getTimestamp("expires_at") != null ? 
                rs.getTimestamp("expires_at").toLocalDateTime() : null
        );
    }
} 