package com.mycompany.myapp.agents;

import dev.langchain4j.model.chat.ChatModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A configurable implementation of the Agent interface.
 */
public class ConfigurableAgent implements Agent {
    
    private static final Logger log = LoggerFactory.getLogger(ConfigurableAgent.class);
    
    private final AgentDefinition definition;
    private final ChatModel chatModel;
    
    public ConfigurableAgent(AgentDefinition definition, ChatModel chatModel) {
        this.definition = definition;
        this.chatModel = chatModel;
    }
    
    @Override
    public AgentDefinition getDefinition() {
        return definition;
    }
    
    @Override
    public String chat(Map<String, Object> context) {
        String systemPrompt = renderSystemPrompt(context);
        String userPrompt = renderUserPrompt(context);
        
        log.debug("System prompt: {}", systemPrompt);
        log.debug("User prompt: {}", userPrompt);
        
        return chatModel.chat(userPrompt);
    }
    
    @Override
    public List<String> streamChat(Map<String, Object> context) {
        String systemPrompt = renderSystemPrompt(context);
        String userPrompt = renderUserPrompt(context);
        
        log.debug("System prompt (streaming): {}", systemPrompt);
        log.debug("User prompt (streaming): {}", userPrompt);
        
        List<String> tokens = new ArrayList<>();
        chatModel.chat(userPrompt).lines().forEach(tokens::add);
        return tokens;
    }
    
    private String renderSystemPrompt(Map<String, Object> context) {
        Map<String, Object> variables = new HashMap<>(context);
        variables.put("agent_name", definition.getName());
        variables.put("agent_description", definition.getDescription());
        variables.put("current_datetime", LocalDateTime.now());
        
        if (definition.getConfiguration() != null) {
            variables.putAll(definition.getConfiguration());
        }
        
        String template = definition.getPromptTemplates().get("system");
        if (template == null) {
            template = "You are a helpful AI assistant named {{agent_name}}. {{agent_description}}";
        }
        
        return renderTemplate(template, variables);
    }
    
    private String renderUserPrompt(Map<String, Object> context) {
        Map<String, Object> variables = new HashMap<>(context);
        if (!variables.containsKey("knowledge_context")) {
            variables.put("knowledge_context", "");
        }
        
        String template = definition.getPromptTemplates().get("user");
        if (template == null) {
            template = "{{user_message}}\n{{#knowledge_context}}Using this relevant knowledge:\n{{knowledge_context}}{{/knowledge_context}}";
        }
        
        return renderTemplate(template, variables);
    }
    
    private String renderTemplate(String template, Map<String, Object> variables) {
        String result = template;
        for (Map.Entry<String, Object> entry : variables.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            String placeholder = "{{" + key + "}}";
            result = result.replace(placeholder, value != null ? value.toString() : "");
            
            // Handle Mustache-style conditionals
            String startTag = "{{#" + key + "}}";
            String endTag = "{{/" + key + "}}";
            int startIndex = result.indexOf(startTag);
            int endIndex = result.indexOf(endTag);
            
            if (startIndex >= 0 && endIndex >= 0) {
                String content = result.substring(startIndex + startTag.length(), endIndex);
                if (value == null || value.toString().isEmpty()) {
                    result = result.substring(0, startIndex) + result.substring(endIndex + endTag.length());
                } else {
                    result = result.substring(0, startIndex) + content + result.substring(endIndex + endTag.length());
                }
            }
        }
        return result;
    }
} 