package com.mycompany.myapp.embeddings;

import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.embedding.Embedding;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Interface for vector storage and similarity search.
 */
public interface VectorStore {
    
    /**
     * Stores an embedding with its associated document.
     * 
     * @param embedding the embedding to store
     * @param document the associated document
     * @return a Mono indicating completion
     */
    Mono<Void> store(Embedding embedding, Document document);
    
    /**
     * Stores multiple embeddings with their associated documents.
     * 
     * @param embeddings the embeddings to store
     * @param documents the associated documents
     * @return a Mono indicating completion
     */
    Mono<Void> storeBatch(List<Embedding> embeddings, List<Document> documents);
    
    /**
     * Searches for similar embeddings to the query embedding.
     * 
     * @param queryEmbedding the embedding to search for
     * @param maxResults the maximum number of results to return
     * @param minSimilarity the minimum similarity threshold (0.0 to 1.0)
     * @return a Flux of search results
     */
    Flux<VectorSearchResult> search(Embedding queryEmbedding, int maxResults, double minSimilarity);
    
    /**
     * Searches for similar embeddings to the query text.
     * 
     * @param queryText the text to search for
     * @param maxResults the maximum number of results to return
     * @param minSimilarity the minimum similarity threshold (0.0 to 1.0)
     * @return a Flux of search results
     */
    Flux<VectorSearchResult> searchByText(String queryText, int maxResults, double minSimilarity);
    
    /**
     * Gets the total number of stored embeddings.
     * 
     * @return a Mono containing the count
     */
    Mono<Long> count();
    
    /**
     * Clears all stored embeddings.
     * 
     * @return a Mono indicating completion
     */
    Mono<Void> clear();
    
    /**
     * Gets the dimension of embeddings stored in this vector store.
     * 
     * @return the embedding dimension
     */
    int getDimension();
    
    /**
     * Represents a search result with similarity score.
     */
    class VectorSearchResult {
        private final Document document;
        private final Embedding embedding;
        private final double similarity;
        
        public VectorSearchResult(Document document, Embedding embedding, double similarity) {
            this.document = document;
            this.embedding = embedding;
            this.similarity = similarity;
        }
        
        public Document getDocument() {
            return document;
        }
        
        public Embedding getEmbedding() {
            return embedding;
        }
        
        public double getSimilarity() {
            return similarity;
        }
        
        @Override
        public String toString() {
            return "VectorSearchResult{" +
                    "similarity=" + similarity +
                    ", document=" + document.text().substring(0, Math.min(100, document.text().length())) + "..." +
                    '}';
        }
    }
} 