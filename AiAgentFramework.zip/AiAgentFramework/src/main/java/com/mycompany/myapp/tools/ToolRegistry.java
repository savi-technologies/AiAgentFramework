package com.mycompany.myapp.tools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registry for managing tools available to agents.
 */
@Component
public class ToolRegistry {
    
    private static final Logger logger = LoggerFactory.getLogger(ToolRegistry.class);
    
    private final Map<String, Tool> tools = new ConcurrentHashMap<>();
    
    public ToolRegistry(List<Tool> availableTools) {
        // Register all available tools
        availableTools.forEach(this::registerTool);
        logger.info("Tool registry initialized with {} tools", tools.size());
    }
    
    /**
     * Registers a tool in the registry.
     * 
     * @param tool the tool to register
     */
    public void registerTool(Tool tool) {
        String toolName = tool.getName();
        tools.put(toolName, tool);
        logger.info("Registered tool: {} - {}", toolName, tool.getDescription());
    }
    
    /**
     * Unregisters a tool from the registry.
     * 
     * @param toolName the name of the tool to unregister
     */
    public void unregisterTool(String toolName) {
        Tool removed = tools.remove(toolName);
        if (removed != null) {
            logger.info("Unregistered tool: {}", toolName);
        }
    }
    
    /**
     * Gets a tool by name.
     * 
     * @param toolName the name of the tool
     * @return a Mono containing the tool if found
     */
    public Mono<Tool> getTool(String toolName) {
        return Mono.fromCallable(() -> {
            Tool tool = tools.get(toolName);
            if (tool == null) {
                throw new IllegalArgumentException("Tool not found: " + toolName);
            }
            if (!tool.isAvailable()) {
                throw new IllegalStateException("Tool not available: " + toolName);
            }
            return tool;
        });
    }
    
    /**
     * Gets all available tools.
     * 
     * @return a Flux of available tools
     */
    public Flux<Tool> getAvailableTools() {
        return Flux.fromIterable(tools.values())
                .filter(Tool::isAvailable);
    }
    
    /**
     * Gets all tool specifications.
     * 
     * @return a Flux of tool specifications
     */
    public Flux<ToolSpecification> getToolSpecifications() {
        return getAvailableTools()
                .map(Tool::getSpecification);
    }
    
    /**
     * Gets a tool specification by tool name.
     * 
     * @param toolName the name of the tool
     * @return a Mono containing the tool specification if found
     */
    public Mono<ToolSpecification> getToolSpecification(String toolName) {
        return getTool(toolName)
                .map(Tool::getSpecification);
    }
    
    /**
     * Executes a tool with the given parameters.
     * 
     * @param toolName the name of the tool to execute
     * @param parameters the parameters for tool execution
     * @param context additional context information
     * @return a Mono containing the tool result
     */
    public Mono<ToolResult> executeTool(String toolName, Map<String, Object> parameters, Map<String, Object> context) {
        return getTool(toolName)
                .flatMap(tool -> {
                    logger.debug("Executing tool: {} with parameters: {}", toolName, parameters);
                    return tool.execute(parameters, context);
                })
                .doOnSuccess(result -> {
                    if (result.isSuccess()) {
                        logger.debug("Tool {} executed successfully in {}ms", toolName, result.getExecutionTimeMs());
                    } else {
                        logger.warn("Tool {} execution failed: {}", toolName, result.getErrorMessage());
                    }
                })
                .onErrorResume(error -> {
                    logger.error("Error executing tool {}: {}", toolName, error.getMessage(), error);
                    return Mono.just(ToolResult.error("Tool execution failed: " + error.getMessage(), error));
                });
    }
    
    /**
     * Checks if a tool is available.
     * 
     * @param toolName the name of the tool
     * @return a Mono containing true if the tool is available
     */
    public Mono<Boolean> isToolAvailable(String toolName) {
        return Mono.fromCallable(() -> {
            Tool tool = tools.get(toolName);
            return tool != null && tool.isAvailable();
        });
    }
    
    /**
     * Gets the number of registered tools.
     * 
     * @return the number of registered tools
     */
    public int getToolCount() {
        return tools.size();
    }
    
    /**
     * Gets the number of available tools.
     * 
     * @return a Mono containing the number of available tools
     */
    public Mono<Long> getAvailableToolCount() {
        return getAvailableTools().count();
    }
} 