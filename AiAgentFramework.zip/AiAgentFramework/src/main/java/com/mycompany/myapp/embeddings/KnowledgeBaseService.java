package com.mycompany.myapp.embeddings;

import dev.langchain4j.data.document.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Service for managing the knowledge base including document loading, embedding generation, and retrieval.
 */
@Service
public class KnowledgeBaseService {
    
    private static final Logger logger = LoggerFactory.getLogger(KnowledgeBaseService.class);
    
    private final DocumentLoader documentLoader;
    private final EmbeddingProvider embeddingProvider;
    private final VectorStore vectorStore;
    private final boolean autoIndexOnStartup;
    
    public KnowledgeBaseService(
            DocumentLoader documentLoader,
            EmbeddingProvider embeddingProvider,
            VectorStore vectorStore,
            @Value("${application.genai.knowledge-base.auto-index:true}") boolean autoIndexOnStartup
    ) {
        this.documentLoader = documentLoader;
        this.embeddingProvider = embeddingProvider;
        this.vectorStore = vectorStore;
        this.autoIndexOnStartup = autoIndexOnStartup;
        
        logger.info("Knowledge base service initialized (auto-index: {})", autoIndexOnStartup);
    }
    
    /**
     * Automatically index documents on application startup.
     */
    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        if (autoIndexOnStartup) {
            logger.info("Auto-indexing documents on startup...");
            indexAllDocuments()
                .subscribe(
                    count -> logger.info("Successfully indexed {} documents", count),
                    error -> logger.error("Failed to auto-index documents: {}", error.getMessage(), error)
                );
        }
    }
    
    /**
     * Loads and indexes all documents from the configured source.
     * 
     * @return a Mono containing the number of indexed documents
     */
    public Mono<Long> indexAllDocuments() {
        logger.info("Starting document indexing process...");
        
        return documentLoader.loadDocuments()
                .collectList()
                .flatMap(documents -> {
                    if (documents.isEmpty()) {
                        logger.warn("No documents found to index");
                        return Mono.just(0L);
                    }
                    
                    logger.info("Found {} documents to index", documents.size());
                    
                    // Convert documents to text and embed them
                    List<String> documentTexts = documents.stream()
                            .map(Document::text)
                            .toList();
                    
                    return embeddingProvider.embedBatch(documentTexts)
                            .collectList()
                            .flatMap(embeddings -> {
                                if (embeddings.size() != documents.size()) {
                                    return Mono.error(new IllegalStateException(
                                        "Mismatch between document count and embedding count"));
                                }
                                
                                return vectorStore.storeBatch(embeddings, documents)
                                        .then(Mono.just((long) documents.size()));
                            });
                })
                .doOnSuccess(count -> logger.info("Document indexing completed. Indexed {} documents", count))
                .doOnError(error -> logger.error("Document indexing failed: {}", error.getMessage(), error));
    }
    
    /**
     * Indexes a single document.
     * 
     * @param document the document to index
     * @return a Mono indicating completion
     */
    public Mono<Void> indexDocument(Document document) {
        logger.debug("Indexing single document of length: {}", document.text().length());
        
        return embeddingProvider.embed(document.text())
                .flatMap(embedding -> vectorStore.store(embedding, document))
                .doOnSuccess(unused -> logger.debug("Successfully indexed document"))
                .doOnError(error -> logger.error("Failed to index document: {}", error.getMessage(), error));
    }
    
    /**
     * Searches the knowledge base for documents similar to the query text.
     * 
     * @param query the search query
     * @param maxResults the maximum number of results to return
     * @param minSimilarity the minimum similarity threshold (0.0 to 1.0)
     * @return a Flux of search results
     */
    public Flux<VectorStore.VectorSearchResult> search(String query, int maxResults, double minSimilarity) {
        logger.debug("Searching knowledge base for: '{}' (max: {}, min similarity: {})", 
                query, maxResults, minSimilarity);
        
        return vectorStore.searchByText(query, maxResults, minSimilarity)
                .doOnNext(result -> logger.debug("Found result with similarity: {:.3f}", result.getSimilarity()))
                .doOnComplete(() -> logger.debug("Knowledge base search completed"));
    }
    
    /**
     * Searches the knowledge base and returns relevant context for RAG.
     * 
     * @param query the search query
     * @param maxResults the maximum number of results to return
     * @return a Mono containing the combined context
     */
    public Mono<String> getRelevantContext(String query, int maxResults) {
        return search(query, maxResults, 0.7) // Use 0.7 as minimum similarity threshold
                .map(result -> result.getDocument().text())
                .reduce((context1, context2) -> context1 + "\n\n" + context2)
                .switchIfEmpty(Mono.just("No relevant context found in knowledge base."))
                .doOnSuccess(context -> logger.debug("Retrieved context of length: {}", context.length()));
    }
    
    /**
     * Clears all indexed documents from the knowledge base.
     * 
     * @return a Mono indicating completion
     */
    public Mono<Void> clearKnowledgeBase() {
        logger.info("Clearing knowledge base...");
        return vectorStore.clear()
                .doOnSuccess(unused -> logger.info("Knowledge base cleared successfully"));
    }
    
    /**
     * Gets the current status of the knowledge base.
     * 
     * @return a Mono containing the knowledge base status
     */
    public Mono<KnowledgeBaseStatus> getStatus() {
        return vectorStore.count()
                .map(count -> {
                    boolean isAvailable = true;
                    if (embeddingProvider instanceof OpenAiEmbeddingProvider) {
                        isAvailable = ((OpenAiEmbeddingProvider) embeddingProvider).isAvailable();
                    }
                    
                    return new KnowledgeBaseStatus(
                            count,
                            isAvailable,
                            embeddingProvider.getProviderName(),
                            vectorStore.getDimension()
                    );
                })
                .doOnSuccess(status -> logger.debug("Knowledge base status: {}", status));
    }
    
    /**
     * Re-indexes all documents (clears existing and rebuilds).
     * 
     * @return a Mono containing the number of indexed documents
     */
    public Mono<Long> reindexAllDocuments() {
        logger.info("Re-indexing all documents...");
        return clearKnowledgeBase()
                .then(indexAllDocuments());
    }
    
    /**
     * Represents the status of the knowledge base.
     */
    public static class KnowledgeBaseStatus {
        private final long documentCount;
        private final boolean embeddingProviderAvailable;
        private final String embeddingProviderName;
        private final int embeddingDimension;
        
        public KnowledgeBaseStatus(long documentCount, boolean embeddingProviderAvailable, 
                                 String embeddingProviderName, int embeddingDimension) {
            this.documentCount = documentCount;
            this.embeddingProviderAvailable = embeddingProviderAvailable;
            this.embeddingProviderName = embeddingProviderName;
            this.embeddingDimension = embeddingDimension;
        }
        
        public long getDocumentCount() {
            return documentCount;
        }
        
        public boolean isEmbeddingProviderAvailable() {
            return embeddingProviderAvailable;
        }
        
        public String getEmbeddingProviderName() {
            return embeddingProviderName;
        }
        
        public int getEmbeddingDimension() {
            return embeddingDimension;
        }
        
        @Override
        public String toString() {
            return "KnowledgeBaseStatus{" +
                    "documentCount=" + documentCount +
                    ", embeddingProvider='" + embeddingProviderName + '\'' +
                    ", available=" + embeddingProviderAvailable +
                    ", dimension=" + embeddingDimension +
                    '}';
        }
    }
} 