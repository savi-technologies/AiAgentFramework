package com.mycompany.myapp.agents;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Map;

/**
 * Definition of an AI agent.
 */
public class AgentDefinition {
    private String name;
    private String description;
    private boolean enabled;
    private Map<String, String> promptTemplates;
    private String model;
    private Double temperature;
    private Integer maxTokens;
    private List<String> tools;
    private Map<String, Object> configuration;
    private Double minSimilarity;
    
    public AgentDefinition() {
        // Default constructor for Jackson
    }
    
    @JsonCreator
    public AgentDefinition(
        @JsonProperty("name") String name,
        @JsonProperty("description") String description,
        @JsonProperty("enabled") boolean enabled,
        @JsonProperty("promptTemplates") Map<String, String> promptTemplates,
        @JsonProperty("model") String model,
        @JsonProperty("temperature") Double temperature,
        @JsonProperty("maxTokens") Integer maxTokens,
        @JsonProperty("tools") List<String> tools,
        @JsonProperty("configuration") Map<String, Object> configuration,
        @JsonProperty("minSimilarity") Double minSimilarity
    ) {
        this.name = name;
        this.description = description;
        this.enabled = enabled;
        this.promptTemplates = promptTemplates;
        this.model = model;
        this.temperature = temperature;
        this.maxTokens = maxTokens;
        this.tools = tools;
        this.configuration = configuration;
        this.minSimilarity = minSimilarity;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public Map<String, String> getPromptTemplates() {
        return promptTemplates;
    }
    
    public void setPromptTemplates(Map<String, String> promptTemplates) {
        this.promptTemplates = promptTemplates;
    }
    
    public String getModel() {
        return model;
    }
    
    public void setModel(String model) {
        this.model = model;
    }
    
    public Double getTemperature() {
        return temperature;
    }
    
    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }
    
    public Integer getMaxTokens() {
        return maxTokens;
    }
    
    public void setMaxTokens(Integer maxTokens) {
        this.maxTokens = maxTokens;
    }
    
    public List<String> getTools() {
        return tools;
    }
    
    public void setTools(List<String> tools) {
        this.tools = tools;
    }
    
    public Map<String, Object> getConfiguration() {
        return configuration;
    }
    
    public void setConfiguration(Map<String, Object> configuration) {
        this.configuration = configuration;
    }
    
    public Double getMinSimilarity() {
        return minSimilarity;
    }
    
    public void setMinSimilarity(Double minSimilarity) {
        this.minSimilarity = minSimilarity;
    }
} 