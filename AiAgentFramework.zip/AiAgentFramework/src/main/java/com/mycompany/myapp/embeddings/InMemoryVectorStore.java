package com.mycompany.myapp.embeddings;

import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.embedding.Embedding;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * In-memory implementation of VectorStore using cosine similarity for search.
 */
@Component
public class InMemoryVectorStore implements VectorStore {
    
    private static final Logger logger = LoggerFactory.getLogger(InMemoryVectorStore.class);
    
    private final ConcurrentHashMap<String, EmbeddingEntry> embeddings = new ConcurrentHashMap<>();
    private final AtomicLong idGenerator = new AtomicLong(0);
    private final EmbeddingProvider embeddingProvider;
    private final int dimension;
    
    public InMemoryVectorStore(EmbeddingProvider embeddingProvider) {
        this.embeddingProvider = embeddingProvider;
        this.dimension = embeddingProvider.getDimension();
        logger.info("Initialized in-memory vector store with {} dimensions", dimension);
    }
    
    @Override
    public Mono<Void> store(Embedding embedding, Document document) {
        return Mono.fromRunnable(() -> {
            String id = "emb_" + idGenerator.incrementAndGet();
            EmbeddingEntry entry = new EmbeddingEntry(id, embedding, document);
            embeddings.put(id, entry);
            
            logger.debug("Stored embedding {} for document of length {}", id, document.text().length());
        });
    }
    
    @Override
    public Mono<Void> storeBatch(List<Embedding> embeddingList, List<Document> documents) {
        if (embeddingList.size() != documents.size()) {
            return Mono.error(new IllegalArgumentException("Embeddings and documents lists must have the same size"));
        }
        
        return Flux.range(0, embeddingList.size())
                .flatMap(i -> store(embeddingList.get(i), documents.get(i)))
                .then();
    }
    
    @Override
    public Flux<VectorSearchResult> search(Embedding queryEmbedding, int maxResults, double minSimilarity) {
        return Mono.fromCallable(() -> {
            List<VectorSearchResult> results = new ArrayList<>();
            
            for (EmbeddingEntry entry : embeddings.values()) {
                double similarity = cosineSimilarity(queryEmbedding, entry.embedding);
                
                if (similarity >= minSimilarity) {
                    results.add(new VectorSearchResult(entry.document, entry.embedding, similarity));
                }
            }
            
            // Sort by similarity (descending) and limit results
            results.sort(Comparator.comparingDouble(VectorSearchResult::getSimilarity).reversed());
            
            if (results.size() > maxResults) {
                results = results.subList(0, maxResults);
            }
            
            logger.debug("Found {} similar embeddings (min similarity: {})", results.size(), minSimilarity);
            return results;
        }).flatMapMany(Flux::fromIterable);
    }
    
    @Override
    public Flux<VectorSearchResult> searchByText(String queryText, int maxResults, double minSimilarity) {
        return embeddingProvider.embed(queryText)
                .flatMapMany(queryEmbedding -> search(queryEmbedding, maxResults, minSimilarity));
    }
    
    @Override
    public Mono<Long> count() {
        return Mono.just((long) embeddings.size());
    }
    
    @Override
    public Mono<Void> clear() {
        return Mono.fromRunnable(() -> {
            int size = embeddings.size();
            embeddings.clear();
            idGenerator.set(0);
            logger.info("Cleared {} embeddings from vector store", size);
        });
    }
    
    @Override
    public int getDimension() {
        return dimension;
    }
    
    /**
     * Calculates cosine similarity between two embeddings.
     * 
     * @param a first embedding
     * @param b second embedding
     * @return cosine similarity (0.0 to 1.0)
     */
    private double cosineSimilarity(Embedding a, Embedding b) {
        float[] vectorA = a.vector();
        float[] vectorB = b.vector();
        
        if (vectorA.length != vectorB.length) {
            throw new IllegalArgumentException("Embedding dimensions must match");
        }
        
        double dotProduct = 0.0;
        double normA = 0.0;
        double normB = 0.0;
        
        for (int i = 0; i < vectorA.length; i++) {
            dotProduct += vectorA[i] * vectorB[i];
            normA += vectorA[i] * vectorA[i];
            normB += vectorB[i] * vectorB[i];
        }
        
        double similarity = dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
        
        // Normalize to 0.0 - 1.0 range (cosine similarity is -1.0 to 1.0)
        return (similarity + 1.0) / 2.0;
    }
    
    /**
     * Internal class to store embedding with associated document.
     */
    private static class EmbeddingEntry {
        final String id;
        final Embedding embedding;
        final Document document;
        
        EmbeddingEntry(String id, Embedding embedding, Document document) {
            this.id = id;
            this.embedding = embedding;
            this.document = document;
        }
    }
} 