package com.mycompany.myapp.config;

import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.time.Duration;

@Configuration
public class ChatModelConfiguration {

    @Bean
    @Primary
    public ChatModel chatModel(ApplicationProperties properties) {
        ApplicationProperties.ChatModel config = properties.getGenai().getChatModel();
        
        return OpenAiChatModel.builder()
            .apiKey(config.getApiKey())
            .modelName(config.getModel())
            .temperature(config.getTemperature())
            .maxTokens(config.getMaxTokens())
            .timeout(Duration.ofSeconds(config.getTimeoutSeconds()))
            .build();
    }
} 