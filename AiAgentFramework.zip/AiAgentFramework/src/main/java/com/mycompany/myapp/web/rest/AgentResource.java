package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.agents.Agent;
import com.mycompany.myapp.agents.AgentDefinition;
import com.mycompany.myapp.agents.AgentRegistry;
import com.mycompany.myapp.memory.Memory;
import com.mycompany.myapp.memory.MemoryProvider;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;
import com.mycompany.myapp.web.rest.vm.AgentChatRequest;
import com.mycompany.myapp.web.rest.vm.AgentChatResponse;
import com.mycompany.myapp.web.rest.vm.AgentMemoryRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * REST controller for managing AI agents.
 */
@RestController
@RequestMapping("/api/agents")
public class AgentResource {

    private final Logger log = LoggerFactory.getLogger(AgentResource.class);

    private final AgentRegistry agentRegistry;
    private final MemoryProvider memoryProvider;

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    public AgentResource(AgentRegistry agentRegistry, MemoryProvider memoryProvider) {
        this.agentRegistry = agentRegistry;
        this.memoryProvider = memoryProvider;
    }

    /**
     * {@code GET /agents} : get all agents.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of agents.
     */
    @GetMapping
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public Mono<ResponseEntity<List<AgentDefinition>>> getAllAgents() {
        log.debug("REST request to get all Agents");
        return agentRegistry.getAllAgentsAsync()
            .collectList()
            .map(ResponseEntity::ok);
    }

    /**
     * {@code GET /agents/config/:name} : get agent configuration by name.
     *
     * @param name the name of the agent.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the agent configuration.
     */
    @GetMapping("/config/{name}")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public Mono<ResponseEntity<AgentDefinition>> getAgentConfig(@PathVariable String name) {
        log.debug("REST request to get Agent config: {}", name);
        return agentRegistry.getAgentDefinitionAsync(name)
            .map(ResponseEntity::ok)
            .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    /**
     * {@code POST /agents/chat} : Chat with an agent.
     *
     * @param request the chat request.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the chat response.
     */
    @PostMapping("/chat")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public Mono<ResponseEntity<AgentChatResponse>> chat(@Valid @RequestBody AgentChatRequest request) {
        log.debug("REST request to chat with Agent: {}", request.getAgentName());

        return agentRegistry.getAgentAsync(request.getAgentName())
            .switchIfEmpty(Mono.error(new BadRequestAlertException("Agent not found", "agent", "agentnotfound")))
            .flatMap(agent -> {
                Map<String, Object> context = new HashMap<>();
                if (request.isIncludeMemoryContext()) {
                    List<Memory> relevantMemories = memoryProvider.searchContent(request.getMessage());
                    if (!relevantMemories.isEmpty()) {
                        context.put("knowledge_context", relevantMemories.get(0).getContent());
                    }
                }
                context.put("user_message", request.getMessage());

                String response = agent.chat(context);
                AgentChatResponse chatResponse = new AgentChatResponse(request.getAgentName(), response);
                chatResponse.setConversationId(UUID.randomUUID().toString());
                return Mono.just(ResponseEntity.ok(chatResponse));
            });
    }

    /**
     * {@code POST /agents/chat/stream} : Chat with an agent with streaming response.
     *
     * @param request the chat request.
     * @return the streaming response.
     */
    @PostMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public Flux<String> streamChat(@Valid @RequestBody AgentChatRequest request) {
        log.debug("REST request to stream chat with Agent: {}", request.getAgentName());

        return agentRegistry.getAgentAsync(request.getAgentName())
            .switchIfEmpty(Mono.error(new BadRequestAlertException("Agent not found", "agent", "agentnotfound")))
            .flatMapMany(agent -> {
                Map<String, Object> context = new HashMap<>();
                if (request.isIncludeMemoryContext()) {
                    List<Memory> relevantMemories = memoryProvider.searchContent(request.getMessage());
                    if (!relevantMemories.isEmpty()) {
                        context.put("knowledge_context", relevantMemories.get(0).getContent());
                    }
                }
                context.put("user_message", request.getMessage());

                return Flux.fromIterable(agent.streamChat(context))
                    .map(token -> "data: " + token + "\n\n");
            });
    }

    /**
     * {@code POST /agents/memory} : Store a memory.
     *
     * @param request the memory request.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the stored memory.
     */
    @PostMapping("/memory")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public Mono<ResponseEntity<Memory>> storeMemory(@Valid @RequestBody AgentMemoryRequest request) {
        log.debug("REST request to store memory: {}", request.getTitle());

        return Mono.fromCallable(() -> memoryProvider.store(
            request.getTitle(),
            request.getContent(),
            LocalDateTime.now().plusMinutes(request.getTtlMinutes())
        )).map(ResponseEntity::ok);
    }

    /**
     * {@code GET /agents/memory/search} : Search memories.
     *
     * @param query the search query.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of matching memories.
     */
    @GetMapping("/memory/search")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public Mono<ResponseEntity<List<Memory>>> searchMemories(@RequestParam String query) {
        log.debug("REST request to search memories: {}", query);
        return Mono.fromCallable(() -> memoryProvider.searchContent(query))
            .map(ResponseEntity::ok);
    }
} 