package com.mycompany.myapp.agents;

import dev.langchain4j.model.chat.ChatModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory implementation of AgentRegistry.
 */
@Component
public class InMemoryAgentRegistry implements AgentRegistry {
    
    private static final Logger log = LoggerFactory.getLogger(InMemoryAgentRegistry.class);
    
    private final Map<String, Agent> agents = new ConcurrentHashMap<>();
    private final Map<String, AgentDefinition> definitions = new ConcurrentHashMap<>();
    private final ChatModel chatModel;
    
    public InMemoryAgentRegistry(ChatModel chatModel) {
        this.chatModel = chatModel;
    }
    
    @Override
    public Optional<Agent> getAgent(String name) {
        return Optional.ofNullable(agents.get(name));
    }
    
    @Override
    public Mono<Agent> getAgentAsync(String name) {
        return Mono.justOrEmpty(getAgent(name));
    }
    
    @Override
    public Optional<AgentDefinition> getAgentDefinition(String name) {
        return Optional.ofNullable(definitions.get(name));
    }
    
    @Override
    public Mono<AgentDefinition> getAgentDefinitionAsync(String name) {
        return Mono.justOrEmpty(getAgentDefinition(name));
    }
    
    @Override
    public List<AgentDefinition> getAllAgentDefinitions() {
        return new ArrayList<>(definitions.values());
    }
    
    @Override
    public Flux<AgentDefinition> getAllAgentsAsync() {
        return Flux.fromIterable(getAllAgentDefinitions());
    }
    
    @Override
    public Flux<AgentDefinition> getEnabledAgents() {
        return getAllAgentsAsync()
            .filter(AgentDefinition::isEnabled);
    }
    
    @Override
    public Agent getOrCreateAgent(AgentDefinition definition) {
        return agents.computeIfAbsent(definition.getName(), name -> {
            definitions.put(name, definition);
            return new ConfigurableAgent(definition, chatModel);
        });
    }
    
    @Override
    public void registerAgent(Agent agent) {
        String name = agent.getName();
        agents.put(name, agent);
        definitions.put(name, agent.getDefinition());
        log.info("Registered agent: {}", name);
    }
    
    @Override
    public Mono<Void> registerAgentAsync(AgentDefinition definition) {
        return Mono.fromRunnable(() -> {
            Agent agent = getOrCreateAgent(definition);
            registerAgent(agent);
        });
    }
    
    @Override
    public void unregisterAgent(String name) {
        agents.remove(name);
        definitions.remove(name);
        log.info("Unregistered agent: {}", name);
    }
    
    @Override
    public Mono<Void> removeAgentAsync(String name) {
        return Mono.fromRunnable(() -> unregisterAgent(name));
    }
    
    @Override
    public Mono<Void> reloadAgents() {
        return Mono.fromRunnable(() -> {
            agents.clear();
            definitions.clear();
            log.info("Cleared agent registry");
        });
    }
    
    @Override
    public Mono<Boolean> isAgentAvailable(String name) {
        return getAgentAsync(name)
            .map(Agent::isEnabled)
            .defaultIfEmpty(false);
    }
} 