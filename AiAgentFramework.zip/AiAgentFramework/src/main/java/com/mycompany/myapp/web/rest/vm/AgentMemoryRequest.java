package com.mycompany.myapp.web.rest.vm;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

/**
 * View Model object for agent memory requests.
 */
public class AgentMemoryRequest {
    
    @NotNull
    @NotEmpty
    private String title;
    
    @NotNull
    @NotEmpty
    private String content;
    
    @Positive
    private int ttlMinutes = 60;  // Default 1 hour
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public int getTtlMinutes() {
        return ttlMinutes;
    }
    
    public void setTtlMinutes(int ttlMinutes) {
        this.ttlMinutes = ttlMinutes;
    }
    
    @Override
    public String toString() {
        return "AgentMemoryRequest{" +
            "title='" + title + '\'' +
            ", content='" + content + '\'' +
            ", ttlMinutes=" + ttlMinutes +
            '}';
    }
} 