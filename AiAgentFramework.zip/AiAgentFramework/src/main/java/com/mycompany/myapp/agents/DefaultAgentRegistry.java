package com.mycompany.myapp.agents;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.mycompany.myapp.chat.ChatModelFactory;
import com.mycompany.myapp.chat.ChatModelType;
import com.mycompany.myapp.config.ApplicationProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;
import org.springframework.context.annotation.Primary;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Default implementation of the AgentRegistry that loads agent configurations from YAML files.
 */
@Component
@Primary
public class DefaultAgentRegistry implements AgentRegistry {
    
    private static final Logger log = LoggerFactory.getLogger(DefaultAgentRegistry.class);
    
    private final Map<String, Agent> agents = new ConcurrentHashMap<>();
    private final Map<String, AgentDefinition> definitions = new ConcurrentHashMap<>();
    private final ChatModelFactory chatModelFactory;
    private final ApplicationProperties applicationProperties;
    private final ObjectMapper yamlMapper;
    
    public DefaultAgentRegistry(ChatModelFactory chatModelFactory, ApplicationProperties applicationProperties) {
        this.chatModelFactory = chatModelFactory;
        this.applicationProperties = applicationProperties;
        this.yamlMapper = new ObjectMapper(new YAMLFactory());
    }
    
    @PostConstruct
    public void init() {
        reloadAgents().subscribe();
    }
    
    @Override
    public Mono<Agent> getAgentAsync(String name) {
        return Mono.justOrEmpty(getAgent(name));
    }
    
    @Override
    public Optional<Agent> getAgent(String name) {
        return Optional.ofNullable(agents.get(name));
    }
    
    @Override
    public Mono<AgentDefinition> getAgentDefinitionAsync(String name) {
        return Mono.justOrEmpty(getAgentDefinition(name));
    }
    
    @Override
    public Optional<AgentDefinition> getAgentDefinition(String name) {
        return Optional.ofNullable(definitions.get(name));
    }
    
    @Override
    public Flux<AgentDefinition> getEnabledAgents() {
        return Flux.fromIterable(definitions.values())
            .filter(AgentDefinition::isEnabled);
    }
    
    @Override
    public Flux<AgentDefinition> getAllAgentsAsync() {
        return Flux.fromIterable(definitions.values());
    }
    
    @Override
    public List<AgentDefinition> getAllAgentDefinitions() {
        return new ArrayList<>(definitions.values());
    }
    
    @Override
    public Agent getOrCreateAgent(AgentDefinition definition) {
        return agents.computeIfAbsent(definition.getName(), name -> {
            log.debug("Creating new agent instance: {}", name);
            return new ConfigurableAgent(
                definition,
                chatModelFactory.createChatModel(
                    ChatModelType.OPENAI,
                    applicationProperties.getGenai().getChatModel().getApiKey(),
                    definition.getModel(),
                    definition.getTemperature(),
                    definition.getMaxTokens(),
                    applicationProperties.getGenai().getChatModel().getTimeoutSeconds()
                )
            );
        });
    }
    
    @Override
    public Mono<Void> registerAgentAsync(AgentDefinition definition) {
        return Mono.fromRunnable(() -> {
            definitions.put(definition.getName(), definition);
            if (definition.isEnabled()) {
                getOrCreateAgent(definition);
            }
        });
    }
    
    @Override
    public void registerAgent(Agent agent) {
        agents.put(agent.getName(), agent);
    }
    
    @Override
    public Mono<Void> removeAgentAsync(String name) {
        return Mono.fromRunnable(() -> unregisterAgent(name));
    }
    
    @Override
    public void unregisterAgent(String name) {
        agents.remove(name);
        definitions.remove(name);
    }
    
    @Override
    public Mono<Void> reloadAgents() {
        return Mono.fromCallable(() -> {
            log.debug("Reloading agent configurations...");
            
            // Clear existing agents
            agents.clear();
            definitions.clear();
            
            // Load agent configurations from YAML files
            PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
            String configPath = applicationProperties.getGenai().getAgents().getConfigPath();
            String pattern = configPath.startsWith("classpath:") ? configPath + "/*.yml" : "file:" + configPath + "/*.yml";
            
            Resource[] resources = resolver.getResources(pattern);
            for (Resource resource : resources) {
                try {
                    AgentDefinition definition = yamlMapper.readValue(resource.getInputStream(), AgentDefinition.class);
                    log.debug("Loaded agent configuration: {}", definition.getName());
                    definitions.put(definition.getName(), definition);
                    if (definition.isEnabled()) {
                        getOrCreateAgent(definition);
                    }
                } catch (IOException e) {
                    log.error("Failed to load agent configuration from {}: {}", resource.getFilename(), e.getMessage());
                }
            }
            
            // Load agent configurations from application properties
            Map<String, ApplicationProperties.AgentConfiguration> configuredAgents = applicationProperties.getGenai().getAgents().getConfigurations();
            for (Map.Entry<String, ApplicationProperties.AgentConfiguration> entry : configuredAgents.entrySet()) {
                ApplicationProperties.AgentConfiguration config = entry.getValue();
                AgentDefinition definition = new AgentDefinition();
                definition.setName(entry.getKey());
                definition.setDescription(config.getDescription());
                definition.setEnabled(config.isEnabled());
                definition.setModel(config.getModel());
                definition.setTemperature(config.getTemperature());
                definition.setMaxTokens(config.getMaxTokens());
                definition.setPromptTemplates(config.getPromptTemplates());
                
                log.debug("Loaded agent configuration from properties: {}", definition.getName());
                definitions.put(definition.getName(), definition);
                if (definition.isEnabled()) {
                    getOrCreateAgent(definition);
                }
            }
            
            return null;
        }).then();
    }
    
    @Override
    public Mono<Boolean> isAgentAvailable(String name) {
        return Mono.fromCallable(() -> {
            AgentDefinition definition = definitions.get(name);
            return definition != null && definition.isEnabled();
        });
    }
} 