package com.mycompany.myapp.tools;

import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * Interface for tools that can be executed by agents to interact with external systems.
 */
public interface Tool {
    
    /**
     * Gets the unique name of this tool.
     * 
     * @return the tool name
     */
    String getName();
    
    /**
     * Gets a description of what this tool does.
     * 
     * @return the tool description
     */
    String getDescription();
    
    /**
     * Gets the tool specification including parameters and their types.
     * 
     * @return the tool specification
     */
    ToolSpecification getSpecification();
    
    /**
     * Executes the tool with the given parameters.
     * 
     * @param parameters the parameters for tool execution
     * @param context additional context information
     * @return a Mono containing the execution result
     */
    Mono<ToolResult> execute(Map<String, Object> parameters, Map<String, Object> context);
    
    /**
     * Validates the parameters before execution.
     * 
     * @param parameters the parameters to validate
     * @return true if parameters are valid
     */
    boolean validateParameters(Map<String, Object> parameters);
    
    /**
     * Checks if the tool is currently available for execution.
     * 
     * @return true if the tool is available
     */
    boolean isAvailable();
} 