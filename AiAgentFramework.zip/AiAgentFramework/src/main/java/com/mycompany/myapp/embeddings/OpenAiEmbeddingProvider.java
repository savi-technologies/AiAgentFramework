package com.mycompany.myapp.embeddings;

import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.model.openai.OpenAiEmbeddingModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;

/**
 * OpenAI implementation of EmbeddingProvider using OpenAI's embedding models.
 */
@Component
public class OpenAiEmbeddingProvider implements EmbeddingProvider {
    
    private static final Logger logger = LoggerFactory.getLogger(OpenAiEmbeddingProvider.class);
    
    private final EmbeddingModel embeddingModel;
    
    public OpenAiEmbeddingProvider(
            @Value("${application.genai.embeddings.api-key:${OPENAI_API_KEY:}}") String apiKey,
            @Value("${application.genai.embeddings.model:text-embedding-ada-002}") String modelName
    ) {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalArgumentException("OpenAI API key is required for embedding provider");
        }
        
        this.embeddingModel = OpenAiEmbeddingModel.builder()
                .apiKey(apiKey)
                .modelName(modelName)
                .timeout(Duration.ofSeconds(30))
                .build();
        
        logger.info("OpenAI embedding provider initialized with model: {}", modelName);
    }
    
    @Override
    public Mono<Embedding> embed(String text) {
        return Mono.fromCallable(() -> {
            try {
                logger.debug("Generating embedding for text of length: {}", text.length());
                
                Embedding embedding = embeddingModel.embed(text).content();
                
                logger.debug("Generated embedding with {} dimensions", embedding.dimension());
                return embedding;
                
            } catch (Exception e) {
                logger.error("Error generating embedding: {}", e.getMessage(), e);
                throw new RuntimeException("Failed to generate embedding: " + e.getMessage(), e);
            }
        });
    }
    
    @Override
    public Flux<Embedding> embedBatch(List<String> texts) {
        return Flux.fromIterable(texts)
                .flatMap(this::embed)
                .onErrorContinue((error, text) -> {
                    logger.error("Error generating embedding for text: {}", error.getMessage(), error);
                });
    }
    
    /**
     * Generates an embedding for a document (convenience method).
     * 
     * @param document the document to embed
     * @return a Mono containing the embedding
     */
    public Mono<Embedding> embedDocument(Document document) {
        String content = document.text();
        return embed(content)
                .doOnSuccess(embedding -> {
                    logger.debug("Generated embedding for document (length: {}, dimensions: {})", 
                        content.length(), 
                        embedding.dimension());
                });
    }
    
    /**
     * Generates embeddings for multiple documents (convenience method).
     * 
     * @param documents the documents to embed
     * @return a Flux of embeddings
     */
    public Flux<Embedding> embedDocuments(List<Document> documents) {
        return Flux.fromIterable(documents)
                .flatMap(this::embedDocument)
                .onErrorContinue((error, document) -> {
                    logger.error("Error generating embedding for document: {}", 
                        error.getMessage(), error);
                });
    }
    
    /**
     * Checks if the embedding provider is available.
     * 
     * @return true if the provider is available
     */
    public boolean isAvailable() {
        try {
            // Test with a small sample
            embeddingModel.embed("test");
            return true;
        } catch (Exception e) {
            logger.warn("Embedding provider not available: {}", e.getMessage());
            return false;
        }
    }
    
    @Override
    public String getProviderName() {
        return "openai";
    }
    
    @Override
    public int getDimension() {
        // OpenAI text-embedding-ada-002 has 1536 dimensions
        // This should ideally be dynamic based on the model
        return 1536;
    }
} 