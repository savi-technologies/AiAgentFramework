# Sample Knowledge Base Document

This is a sample document for testing the GenAI Platform document loading functionality.

## Overview

The GenAI Platform supports loading documents from the local file system for knowledge base operations.

## Features

- **Document Loading**: Load documents from various file formats (txt, md, pdf, docx, html)
- **Embeddings**: Generate embeddings for semantic search
- **Vector Search**: Search through documents using vector similarity
- **Agent Integration**: Agents can query the knowledge base using tools

## Usage

Documents placed in the configured documents directory will be automatically discovered and loaded into the knowledge base for agent use.

## Sample Data

This document contains sample information that agents can use to answer questions about the platform capabilities.

The platform supports:
1. Multiple chat model providers (OpenAI, Anthropic, Ollama)
2. Pluggable embedding systems
3. Configurable agents
4. Streaming responses with progress updates
5. Tool integration for external system interactions 