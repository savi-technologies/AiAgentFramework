-- Create the database if it doesn't exist
CREATE DATABASE ai_agent_db; 